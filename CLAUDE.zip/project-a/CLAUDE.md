# CLAUDE.md — CyclePay API

## 0. 기본 원칙
- 작업 전 소스 전체를 분석하고 학습한다. 이 프로젝트가 무엇인지, 어떤 역할인지 파악하는 것은 기본이다.
- 모든 작업은 분석 → 보고 → 승인 → 적용 순서로 진행한다.
- 보안 민감 정보 (API 키, 비밀번호, 내부 IP 등)는 절대 노출하지 않는다.
- 보안 민감 정보는 Read를 제외한 모든 행위에 대해서 절대 임의로 진행하지 않는다. (반드시 승인 후 진행한다)

---

## 1. 프로젝트 정체성
- **이름**: CyclePay API
- **목적**: CyclePay 서비스의 백엔드 API 서버
- **역할**: 핵심 비즈니스 로직 처리 및 API 제공

---

## 2. 기술 스택
- **Language**: Java
- **Framework**: Spring Boot
- **Build**: Maven, Jib (Container), GraalVM Native Image
- **DB**: Oracle (운영/개발), H2 (로컬) / JPA + QueryDSL
- **Cache**: Redis (Cluster) - 동시접근 방지 및 데이터 캐싱
- **Cloud (OCI)**: Object Storage, Vault (KMS)
- **External**: PG (KCP), Slack (Notification), NHN Toast (알림톡)
- **Utils**: MapStruct (Mapping), SpringDoc (OpenAPI)

---

## 3. 아키텍처
- **패턴**: DDD 4계층 아키텍처
  - Presentation → Application → Domain → Infrastructure
- Infrastructure 레이어는 프로젝트에서 `infra`로 표기한다.

### 어노테이션 규칙
- `@Configuration`: 설정 관련 클래스
- `@Controller`, `@RestController`: 컨트롤러
- `@Service`: 도메인 서비스, 응용 서비스 (**파일명 반드시 `Service`로 끝남**)
- `@Repository`: Repository 구현체
- `@Component`: 그 외 기본
- `@Async`: 현재 파이프라인과 별개로 비동기 처리가 필요한 경우 레이어 구분 없이 사용 가능

---

## 4. 코드 컨벤션

### 공통

#### 명명 규칙
- 모든 명명은 역할에 따라 단수/복수 명시
- 조회=View, 생성=Create, 수정=Modify, 삭제=Delete
- 클래스명: 도메인 + 역할 + 종류
- 이벤트 발행 후 작업 핸들러: 도메인 + On + 이벤트명 + 종류
- 메소드명: 역할 + 도메인
- 변수: 명사, 역할이 명확히 드러나도록
- 클래스: PascalCase / 메소드·변수: camelCase
- 모든 변수, 클래스, 메서드에 명시적이고 설명적인 이름 사용
- 메소드에 역할 주석 필수

#### 주석 규칙

내부 주석:
```java
/*
어떤 기능을 하는지 작성 필요
 */
```

메소드 주석:
```java
/**
 * 해당 메소드의 역할
 * @param {파라미터} 파라미터 역할
 * @return Return 유형 (반환값 없으면 해당 줄 생략)
 */
```

#### DTO 타입 기준
- Command, Query, View, ViewDetail, Result, Event → `record`
- Request, Response, Entity 그 외 → `class`
- 데이터 불변성이 필요한 경우 (Infra Request/Response 등) → `record`

#### 레이어별 접근 제한자
- **Presentation**: 클래스, 메소드 기본 `default`
- **Application**: 클래스, 메소드 기본 `public` / 내부 메소드는 `private`
- **Domain**: 클래스, 메소드 기본 `default` / 패키지 외부에서 사용 시 `public` / 내부 메소드는 `private`
- **Infrastructure**: 클래스, 메소드 기본 `default` / 패키지 외부에서 사용하거나 상속 구현부는 `public` / 내부 메소드는 `private`

#### 코드 포맷팅
- DI 필요 시 `@RequiredArgsConstructor` 사용, 없으면 생략
- 예외: 복잡한 초기화 로직이 필요한 경우 명시적 생성자 사용
- 모든 DI 글로벌 변수(필드)는 하나씩 빈 줄로 구분
- 괄호 `()`, `{}`, `<>` 바깥쪽 양 끝 공백 추가. 어노테이션 포함 (예: `method( param )`, `@Transactional( readOnly = true )`, `Map< String, String >`)
- 중첩 괄호 내부는 공백 없음: `method( a.get(0) )`
- 중괄호: 메소드, 클래스, 제어문 정의 시 `{` 앞에 한 칸 공백 추가
- 메소드 내 변수 선언은 개행으로 나열, 빈 줄로 블록 구분하지 않음
- 함수, if, for 등 블록은 위아래 반드시 빈 줄로 구분
- 역할이 다른 코드 블록은 빈 줄로 구분
- 메서드 체이닝은 각 체인을 줄 바꿔 `.` 기준으로 수직 정렬한다 (빌더, 스트림, QueryDSL 등 모든 체이닝 포함)

```java
String a = "a";
String b = "b";

if ( a.equals(b) ) {
    // ...
}

for ( String item : list ) {
    // ...
}
```

#### return 블록 규칙
- `}` 바로 위 return → 빈 줄 없이 붙임
- 일반 코드 다음 return → 빈 줄로 구분

```java
if ( condition ) {
    doSomething();
}
return result;

// ---

Advertisement advertisement = repository.findAdvertisementById( id )
                                        .orElseThrow( () -> new AdvertisementNotFoundException(id) );

return advertisement;
```

---

### Presentation

#### 명명 규칙
- Controller: `{Domain}Controller`
- Request/Response: `{Domain}CreateRequest`, `{Domain}ViewResponse` 등
- Mapper: `{Domain}Mapper`
- API 경로: `/v1/{도메인복수}`

#### Controller 구조
- PREFIX는 클래스 내 `final static String`으로 선언
- Handler는 필요한 것만 주입
- Mapper는 `Mappers.getMapper( XxxMapper.class )`로 직접 초기화 (Spring Bean 아님)
- 모든 DI 필드는 빈 줄로 구분

```java
@Tag( name = "광고" )
@RequestMapping( AdvertisementController.PREFIX )
@RestController
@RequiredArgsConstructor
class AdvertisementController {
    final static String PREFIX = "/v1/advertisements";

    private final AdvertisementCreateHandler createHandler;

    private final AdvertisementViewHandler viewHandler;

    private final AdvertisementMapper mapper = Mappers.getMapper( AdvertisementMapper.class );
}
```

#### HTTP 메소드 / 응답 코드
- GET (조회): 200 OK
- POST (생성): 응답 있으면 201 CREATED, 없으면 204 NO_CONTENT
- PATCH (수정), DELETE (삭제): 응답 없으면 204 NO_CONTENT
- 생성과 수정을 동시에 처리: PUT

#### OpenAPI / 문서화
- 각 API에 `@Operation( summary, description )` 필수
- GET, DELETE 요청 파라미터: `@Parameter` 사용
- POST, PATCH, PUT 요청 필드: `@Schema` 사용
- `@PathVariable`: `@Parameter( description = "..." )` 설명 필수
- 조회 Request (쿼리 파라미터): `@ParameterObject` 적용
- Body 객체: `@RequestBody` 또는 `@ModelAttribute` 적용
- Creator/Modifier, Pageable: `@Parameter( hidden = true )`로 숨김

#### Request DTO
- `class` 사용
- `@FieldDefaults( level = AccessLevel.PRIVATE )` + `@Getter @Setter` 필수
- 검증이 필요한 필드에만 `@DocConstraint` 적용, 불필요하면 생략
- 중첩 클래스는 `static`으로 선언, `@Schema( name = "XxxRequest.InnerName" )` 명시

#### Response DTO
- `class` 사용
- `@FieldDefaults( level = AccessLevel.PRIVATE )` + `@Getter @Setter` 필수
- 중첩 클래스는 `static`으로 선언, `@Schema( name = "XxxResponse.InnerName" )` 명시

#### Pageable
- `@ParameterObject` Request DTO + `@Parameter( hidden = true )` Pageable 조합
- Mapper에서 Request + Pageable → Query record로 변환

#### MultipartFile (Form-data)
- `consumes = MULTIPART_FORM_DATA_VALUE` + `@ModelAttribute` 조합

#### Mapper
- `extends VOMapper` 필수
- 모든 매핑 메소드명은 `map`으로 통일, 파라미터 타입으로 구분
- `@Mapping`은 필드명 불일치, 표현식, 기본값 지정 등 필요한 경우에만 사용
- 외부로 노출되는 ID, 변환이 필요한 VO 추가 시 VOMapper에 변환 메소드 함께 추가

---

### Application

#### 명명 규칙
- Handler: `{Domain}CreateHandler`, `{Domain}ViewHandler` 등
- EventHandler: `{Domain}On{EventName}EventHandler`
- Command: `{Domain}CreateCommand` (record)
- Query: `{Domain}Query` (record)
- Result (CUD 응답 필요 시): `{Domain}CreateResult` (record)
- 목록 조회 응답: `{Domain}View` (record)
- 단건 상세 조회 응답: `{Domain}ViewDetail` (record)
- Exception: `{Domain}NotFoundException`, `{Domain}BadRequestException` 등

#### Handler 구조
- `@Component` + CUD는 `@Transactional`, View는 `@Transactional( readOnly = true )`
- Entity 없으면 즉시 throw (`orElseThrow`)
- 역할이 다른 코드 블록은 빈 줄로 구분

```java
@Component
@Transactional
@RequiredArgsConstructor
public class AdvertisementCreateHandler {

    /**
     * 광고 등록
     * @param command 광고 등록 정보
     * @return AdvertisementId
     */
    public AdvertisementId createAdvertisement( AdvertisementCreateCommand command ) {
        validationService.validAdvertisementInfo( command );

        Advertisement advertisement = Advertisement.of( command, repository );

        return repository.save( advertisement ).getId();
    }
}
```

#### EventHandler 구조
- `@Component`
- 직접 이벤트 전파: `@EventListener`
- 트랜잭션에 따른 이벤트 전파: `@TransactionalEventListener`
- 동일 이벤트를 처리하는 핸들러가 여러 개일 경우 `@Order`로 실행 순서 지정

#### Exception 구조
- `ResourceBadRequestException` / `ResourceNotFoundException` 상속
- `ErrorStatus` enum으로 메시지 관리
- `ErrorStatus`는 포맷 스트링 지원

```java
public class AdvertisementNotFoundException extends ResourceNotFoundException {
    public AdvertisementNotFoundException( AdvertisementId id ) {
        super( ErrorStatus.ADVERTISEMENT_NOT_FOUND, id );
    }
}
```

---

### Domain

#### 명명 규칙
- Entity: 명사
- Domain Service: `{Domain}ModifyService`, `{Domain}DeleteService` 등
- Domain Event: `{Domain}CreatedEvent`, `{Domain}ModifiedEvent`, `{Domain}DeletedEvent` (역할은 반드시 과거형)
- Repository: `{Domain}Repository`
- ValidationService: `{Domain}ValidationService`
- PK 외부 노출 필요 시: 단건 ID → `{Domain}Id`, 복합키 → `{Domain}Ids` / 내부 전용이면 Entity 내 `@Id` 직접 선언

#### Entity 구조
- `@NoArgsConstructor( access = PROTECTED )` + `@AllArgsConstructor( access = PRIVATE )` 필수
- `@Builder( access = PRIVATE )` 선택
- 외부 직접 생성 불가, 반드시 `static of()` Factory Method로 생성
- 외부 노출 불필요한 필드는 `@Getter( AccessLevel.PRIVATE )`
- `@Transient`: DB에 반영되지 않아야 하는 임시 데이터 보관 시 사용
- 이력 추적이 필요한 경우 `ChangePropertySet` 활용
- 필드별 역할 주석 필수

#### Persistable 구현 기준
- 연관관계가 있고 해당 Entity가 자식인 경우
- 부모 insert 후 자식 insert 시 JPA가 merge로 처리하는 것을 막기 위해 구현
- 자식 insert 없으면 구현 불필요
- 부모 생성 시 `_new`를 `true`로 고정

```java
public @Getter class AdvertisementDetail implements Persistable< AdvertisementDetailId > {
    @Transient
    private boolean _new;

    @Override
    public boolean isNew() { return _new; }
}
```

#### Entity ID (외부 노출 필요 시)
- `@Embeddable` + `Serializable` 구현
- `@NoArgsConstructor( access = PROTECTED )` + `@AllArgsConstructor( access = PRIVATE )` 필수
- `@EqualsAndHashCode`
- `static of( Long id )` (null/음수 → null 반환)
- `toString()`은 id 값만 반환
- 외부 응답 시 Mapper에서 기본 타입으로 변환

#### Repository 인터페이스
- 목록 조회: `findAll{Domain}s( XxxQuery query )`
- 단건 조회: `find{Domain}By{파라미터}( XxxId id )`
- 단건 저장: `save( {Domain} entity )`
- 다건 저장: `saveAll( List< {Domain} > entities )`
- ID 생성: `next{Domain}Id()`

#### ValidationService
- Domain 레이어에 위치
- `@Service`
- 비즈니스 로직 검증 담당
- 검증 실패 시 Exception throw

#### Domain Service
- `@Service`
- 타 도메인이 해당 도메인 Entity에 직접 접근하지 않도록 비즈니스 공간을 열어주는 역할
- 이벤트 발행 역할 포함
- 트랜잭션 선언 없음 (Handler에서 관리)

#### Domain Event
- `record` 사용
- 이름은 반드시 과거형
- Entity 기반 생성자 제공
- 생성 이벤트: `of()` 내부에서 발행
- 수정/삭제 이벤트: Domain Service 또는 Entity 메소드 내부에서 발행

#### Enum
- DB 저장 + 외부 노출: `implements Code` + `@DocEnum` 적용
- DB 저장만 (외부 노출 없음): `implements Code` 만 적용
- 외부 노출만 (DB 저장 없음): `implements Code` + `@DocEnum` 적용. code 필드 없으므로 Code의 code는 기본값 null로 생략 가능
- 내부 전용 (DB 저장 없음, 외부 노출 없음): `implements Code`, `@DocEnum` 모두 불필요
- 코드값 4자리: PascalCase 단어 분리 후 앞 2단어 첫 대문자 조합 + 번호 2자리 (예: AdvertisementType → AT01, AT02)

```java
@DocEnum( "광고 유형" )
public enum AdvertisementType implements Code {
    IMAGE( "AT01", "이미지" ),
    VIDEO( "AT02", "동영상" );

    private final String code;
    private final String name;
}
```

---

### Infrastructure

#### 명명 규칙
- Repository 구현체: `Default{Domain}Repository`
- 외부 통신 비즈니스: `{Channel}API`
- 외부 통신 기술 세부: `{Channel}Handler`
- 설정: `{대상}Configuration`
- 프로퍼티: `{대상}Properties`
- 흐름 설정: `{대상}Resolver`
- JPA↔DB 변환: `{대상}Converter`
- 외부 통신 Request/Response: `record` 사용 (불변)

#### DefaultRepository
- `@Repository`
- JPQLQueryFactory (QueryDSL) + JPARepository 조합
- 동적 쿼리는 `BooleanBuilder` 사용
- Domain Entity 반환이 기본
- record 타입 반환 (Projection) 필요 시 `constructor()`, `list()`, `groupBy()`, `transform()` 활용
- 페이징 처리: `PageableExecutionUtils.getPage()` 사용

#### JPARepository
- ID 분리 시: `CrudRepository< Entity, {Domain}Id >` / 미분리 시: `CrudRepository< Entity, 기본타입 >` 확장
- 시퀀스 필요 시에만 생성, `@Query` Native Query로 Oracle 시퀀스 호출
- 시퀀스도 불필요하고 저장 작업도 없으면 생성 안 함

#### 시퀀스 형식
- `yyMMddHHmmss(12자리)` + `LPAD( SEQ.NEXTVAL, 4, '0' )(4자리)` → 총 16자리
- Entity `of()` 내부에서 `repository.next{Domain}Id()` 호출

#### CodeConverter
- `abstract class CodeConverter< X extends Enum< X > & Code >` 상속
- Enum별 static inner class로 `@Converter( autoApply = true )` 등록

```java
@Converter( autoApply = true )
static class AdvertisementTypeConverter extends CodeConverter< AdvertisementType > {
    AdvertisementTypeConverter() { super( AdvertisementType.class ); }
}
```

#### 외부 API 통신
- RestClient 기반 외부 API 호출
- API 클래스: 비즈니스 로직 담당, `{Domain}Service 구현`
- Handler 클래스: 기술 세부사항 담당, `ExternalAPIHandler< T > 구현`
- `@Retryable` + `@Recover` 적용

#### Properties
- `@ConfigurationProperties( "prefix" )` + `@FieldDefaults( level = PRIVATE )` + `@Getter @Setter`

#### Configuration
- `@Configuration` + `@Bean`
- `@Bean` 생성 메소드는 `public`
- 세부 구현 로직은 `private` 메소드로 캡슐화

---

## 5. 설정
- `application.yml` 프로필: `local`, `develop`, `production`
- `local` 프로필 DB 정보는 내부 접근용으로 평문 노출이 허용된다.