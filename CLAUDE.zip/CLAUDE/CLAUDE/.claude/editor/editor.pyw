"""
Editor - .claude/task/TASK.md · .claude/test/TEST.md 를 화면으로 편집한다 (http://127.0.0.1:7700)

- 더블클릭하면 서버가 뜨고 브라우저가 열린다. 이미 떠 있으면 브라우저만 연다.
- 읽고 쓰는 파일은 TASK.md, TEST.md 두 개뿐이고, 워크스페이스는 폴더 이름만 읽는다.
- 브라우저에는 아무것도 저장하지 않는다. 화면은 이 파일 안에 들어 있다 (외부 리소스 없음).
- md가 바뀌면 바로 화면에 반영하고, 화면 입력은 0.5초 뒤 md에 저장한다.
- 저장하려는 사이 md가 바뀌었으면 저장하지 않고 화면에 충돌을 알린다.
- 브라우저 탭을 모두 닫으면 잠시 뒤 스스로 종료한다 (새로고침은 괜찮음).
"""
import argparse
import hashlib
import json
import queue
import secrets
import threading
import time
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

APP = 'claude-editor'
HOST = '127.0.0.1'
PORT = 7700
POLL_SECONDS = 0.25          # md 변경 확인 간격
HEARTBEAT_SECONDS = 5        # 탭이 닫혔는지 알아채는 간격
IDLE_EXIT_SECONDS = 10       # 탭이 모두 닫힌 뒤 종료까지
FIRST_OPEN_SECONDS = 60      # 처음 브라우저가 붙기를 기다리는 시간
MAX_BODY = 2_000_000


class Docs:
    """TASK.md / TEST.md 두 파일만 다룬다. 줄바꿈(CRLF)·끝 줄바꿈·BOM 은 원래 파일을 따른다."""

    def __init__(self, root):
        claude = root / '.claude'
        self.paths = {'task': claude / 'task' / 'TASK.md', 'test': claude / 'test' / 'TEST.md'}
        self.style = {tab: {'crlf': True, 'final_newline': True, 'bom': False} for tab in self.paths}
        self.lock = threading.Lock()

    @staticmethod
    def version(raw):
        return hashlib.sha1(raw).hexdigest()[:16]

    def read(self, tab):
        path = self.paths[tab]
        if not path.is_file():
            return {'exists': False}
        raw = path.read_bytes()
        text = raw.decode('utf-8')
        bom = text.startswith('﻿')
        if bom:
            text = text[1:]
        style = self.style[tab]
        if '\n' in text:
            style['crlf'] = '\r\n' in text
        style['final_newline'] = text.endswith('\n')
        style['bom'] = bom
        text = text.replace('\r\n', '\n')
        if style['final_newline']:
            text = text[:-1]
        return {'exists': True, 'text': text, 'version': self.version(raw)}

    def write(self, tab, text):
        style = self.style[tab]
        out = text.replace('\r\n', '\n')
        if style['final_newline']:
            out += '\n'
        if style['crlf']:
            out = out.replace('\n', '\r\n')
        raw = (('﻿' if style['bom'] else '') + out).encode('utf-8')
        self.paths[tab].write_bytes(raw)
        return self.version(raw)

    def save(self, tab, text, base, force):
        """base(화면이 마지막으로 본 버전)와 지금 md가 다르면 덮어쓰지 않고 지금 md를 돌려준다."""
        with self.lock:
            current = self.read(tab)
            if not current['exists']:
                return 404, {'error': self.paths[tab].name + ' 파일이 없습니다'}
            if not force and base != current['version']:
                return 409, {'text': current['text'], 'version': current['version']}
            return 200, {'version': self.write(tab, text)}


class Hub:
    """브라우저 탭마다 이벤트(SSE) 연결 하나. 연결 수로 탭이 모두 닫혔는지 판단한다."""

    def __init__(self):
        self.clients = set()
        self.lock = threading.Lock()
        self.seen = False

    def add(self):
        q = queue.Queue()
        with self.lock:
            self.clients.add(q)
            self.seen = True
        return q

    def remove(self, q):
        with self.lock:
            self.clients.discard(q)

    def count(self):
        with self.lock:
            return len(self.clients)

    def publish(self, event, data):
        with self.lock:
            for q in self.clients:
                q.put((event, data))


def folders(root):
    """워크스페이스 루트의 폴더 이름만 (안의 내용은 읽지 않음)."""
    return sorted(p.name for p in root.iterdir() if p.is_dir() and not p.name.startswith('.'))


def stat_key(path):
    try:
        st = path.stat()
        return st.st_mtime_ns, st.st_size
    except OSError:
        return None


def watch(server):
    """md 두 개의 수정 시각·크기를 계속 보다가, 내용이 바뀌면 모든 탭에 알린다."""
    docs, hub = server.docs, server.hub
    last = {tab: stat_key(path) for tab, path in docs.paths.items()}
    with docs.lock:
        versions = {tab: docs.read(tab).get('version') for tab in docs.paths}
    while not server.stopping.wait(POLL_SECONDS):
        for tab, path in docs.paths.items():
            key = stat_key(path)
            if key == last[tab]:
                continue
            last[tab] = key
            with docs.lock:
                doc = docs.read(tab)
            if not doc['exists'] or doc['version'] == versions[tab]:
                continue
            versions[tab] = doc['version']
            hub.publish('file', {'tab': tab, 'text': doc['text'], 'version': doc['version']})


def exit_when_idle(server, started):
    """탭이 모두 닫히고 IDLE_EXIT_SECONDS 가 지나면 종료 (처음엔 브라우저가 붙을 때까지 기다림)."""
    idle_since = None
    while not server.stopping.wait(1):
        if server.hub.count():
            idle_since = None
            continue
        now = time.monotonic()
        if not server.hub.seen:
            if now - started > FIRST_OPEN_SECONDS:
                break
            continue
        if idle_since is None:
            idle_since = now
        elif now - idle_since >= IDLE_EXIT_SECONDS:
            break
    server.shutdown()


PICK_LOCK = threading.Lock()


def pick_file():
    """윈도우 파일 선택창을 띄우고 고른 경로만 돌려준다 (파일 내용은 읽지 않음)."""
    with PICK_LOCK:
        import tkinter
        from tkinter import filedialog
        root = tkinter.Tk()
        root.withdraw()
        root.attributes('-topmost', True)
        try:
            path = filedialog.askopenfilename(parent=root, title='파일 선택 - Editor')
        finally:
            root.destroy()
        return path or None


class Handler(BaseHTTPRequestHandler):
    server_version = 'Editor'

    def log_message(self, fmt, *args):
        pass   # pythonw 로 돌아서 출력할 곳이 없음 (로그 파일도 남기지 않음)

    def allowed(self):
        """다른 사이트가 이 서버로 요청을 보내지 못하게 Host / Origin 을 확인한다."""
        if self.headers.get('Host', '') not in self.server.hosts:
            return False
        origin = self.headers.get('Origin')
        return origin is None or origin in self.server.origins

    def token_ok(self, query):
        return secrets.compare_digest(query.get('t', [''])[0], self.server.token)

    def do_GET(self):
        url = urlsplit(self.path)
        if not self.allowed():
            return self.reply(403, {'error': 'forbidden'})
        if url.path == '/api/ping':
            return self.reply(200, {'app': APP})
        if url.path == '/':
            return self.page()
        if not self.token_ok(parse_qs(url.query)):
            return self.reply(403, {'error': 'token'})
        if url.path == '/api/state':
            return self.reply(200, self.state())
        if url.path == '/api/events':
            return self.events()
        self.reply(404, {'error': 'not found'})

    def do_POST(self):
        url = urlsplit(self.path)
        if not self.allowed() or not self.token_ok(parse_qs(url.query)):
            return self.reply(403, {'error': 'forbidden'})
        length = int(self.headers.get('Content-Length') or 0)
        if length > MAX_BODY:
            return self.reply(413, {'error': 'too large'})
        try:
            body = json.loads(self.rfile.read(length) or b'{}')
        except ValueError:
            return self.reply(400, {'error': 'json'})
        if url.path == '/api/save':
            tab, text = body.get('tab'), body.get('text')
            if tab not in self.server.docs.paths or not isinstance(text, str):
                return self.reply(400, {'error': 'bad request'})
            status, data = self.server.docs.save(tab, text, body.get('base'), bool(body.get('force')))
            return self.reply(status, data)
        if url.path == '/api/pick-file':
            return self.reply(200, {'path': pick_file()})
        self.reply(404, {'error': 'not found'})

    def state(self):
        docs = self.server.docs
        with docs.lock:
            data = {tab: docs.read(tab) for tab in docs.paths}
        data['folders'] = folders(self.server.root)
        return data

    def page(self):
        raw = HTML.replace('__TOKEN__', self.server.token).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy',
                         "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src data:")
        self.end_headers()
        self.wfile.write(raw)

    def events(self):
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        q = self.server.hub.add()
        try:
            self.wfile.write(b': connected\n\n')
            self.wfile.flush()
            while not self.server.stopping.is_set():
                try:
                    event, data = q.get(timeout=HEARTBEAT_SECONDS)
                except queue.Empty:
                    self.wfile.write(b': ping\n\n')
                    self.wfile.flush()
                    continue
                payload = json.dumps(data, ensure_ascii=False)
                self.wfile.write(('event: ' + event + '\ndata: ' + payload + '\n\n').encode('utf-8'))
                self.wfile.flush()
        except OSError:
            pass   # 탭이 닫힘
        finally:
            self.server.hub.remove(q)

    def reply(self, status, data):
        raw = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(raw)


class EditorServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False   # 같은 포트를 두 번 잡지 않게

    def setup_editor(self, root, port):
        self.root = root
        self.docs = Docs(root)
        self.hub = Hub()
        self.token = secrets.token_urlsafe(24)
        self.hosts = {HOST + ':' + str(port), 'localhost:' + str(port)}
        self.origins = {'http://' + h for h in self.hosts}
        self.stopping = threading.Event()


def is_editor(port):
    try:
        with urllib.request.urlopen('http://' + HOST + ':' + str(port) + '/api/ping', timeout=2) as r:
            return json.loads(r.read()).get('app') == APP
    except (OSError, ValueError):
        return False


def alert(message):
    import tkinter
    from tkinter import messagebox
    root = tkinter.Tk()
    root.withdraw()
    messagebox.showerror('Editor', message)
    root.destroy()


def main():
    parser = argparse.ArgumentParser(description='Editor (.claude TASK.md / TEST.md)')
    parser.add_argument('--root', help='워크스페이스 루트 (기본: 이 파일 기준 .claude 의 상위 폴더)')
    parser.add_argument('--port', type=int, default=PORT)
    parser.add_argument('--no-browser', action='store_true', help='브라우저를 열지 않음 (테스트용)')
    args = parser.parse_args()
    root = Path(args.root).resolve() if args.root else Path(__file__).resolve().parents[2]
    url = 'http://' + HOST + ':' + str(args.port) + '/'

    try:
        server = EditorServer((HOST, args.port), Handler)
    except OSError:
        if is_editor(args.port):
            if not args.no_browser:
                webbrowser.open(url)   # 이미 떠 있으면 브라우저만
        else:
            alert(str(args.port) + ' 포트를 다른 프로그램이 쓰고 있어서 Editor를 띄울 수 없습니다.')
        return

    server.setup_editor(root, args.port)
    threading.Thread(target=watch, args=(server,), daemon=True).start()
    threading.Thread(target=exit_when_idle, args=(server, time.monotonic()), daemon=True).start()
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        server.stopping.set()
        server.server_close()


HTML = r"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Editor</title>
<style>
  :root {
    --bg: #0a0c11;
    --glow-1: rgba(99, 102, 241, .17);
    --glow-2: rgba(168, 85, 247, .10);
    --panel: rgba(18, 21, 29, .78);
    --glass: rgba(10, 12, 17, .72);
    --surface: #12151d;
    --surface-2: #181c26;
    --surface-3: #202533;
    --field: rgba(255, 255, 255, .035);
    --border: rgba(255, 255, 255, .07);
    --border-strong: rgba(255, 255, 255, .14);
    --text: #e8ebf2;
    --text-2: #a3acbb;
    --text-3: #687185;
    --accent: #7c8cff;
    --accent-2: #b38cff;
    --accent-soft: rgba(124, 140, 255, .14);
    --accent-text: #aab6ff;
    --ok: #4ade80;
    --ok-soft: rgba(74, 222, 128, .12);
    --warn: #fbbf24;
    --warn-soft: rgba(251, 191, 36, .12);
    --err: #f87171;
    --err-soft: rgba(248, 113, 113, .13);
    --get: #4ade80;
    --post: #7c8cff;
    --put: #fbbf24;
    --patch: #c084fc;
    --delete: #f87171;
    --shadow: 0 1px 0 rgba(255, 255, 255, .03) inset, 0 8px 24px rgba(0, 0, 0, .25);
    --shadow-lg: 0 24px 64px rgba(0, 0, 0, .55);
    --code-bg: #0c0f16;
    --code-head: #11151e;
    --code-text: #c0caf5;
    --code-dim: #4f5876;
    --code-no: #3b4261;
    --t-key: #7aa2f7;
    --t-str: #9ece6a;
    --t-num: #ff9e64;
    --t-bool: #bb9af7;
    --t-br: #a9b1d6;
    --t-pun: #89ddff;
    --t-ref: #e0af68;
    --md-h: #7aa2f7;
    --md-n: #e0af68;
    --md-p: #73daca;
    --md-a: #f7768e;
    --side-w: 232px;
    --sans: "Pretendard Variable", "Pretendard", "SUIT Variable", "Malgun Gothic", "맑은 고딕", "Segoe UI", system-ui, sans-serif;
    --mono: "JetBrains Mono", "D2Coding", "Cascadia Code", Consolas, monospace;
  }

  @media (prefers-color-scheme: light) {
    :root {
      --bg: #f4f5f9;
      --glow-1: rgba(99, 102, 241, .10);
      --glow-2: rgba(168, 85, 247, .06);
      --panel: rgba(255, 255, 255, .78);
      --glass: rgba(244, 245, 249, .78);
      --surface: #ffffff;
      --surface-2: #f4f5f9;
      --surface-3: #eceef5;
      --field: #f8f9fc;
      --border: #e3e6ee;
      --border-strong: #d2d7e2;
      --text: #161922;
      --text-2: #4d5667;
      --text-3: #868fa0;
      --accent: #5b5bf0;
      --accent-2: #9b5cf6;
      --accent-soft: #eef0ff;
      --accent-text: #4545d4;
      --ok: #16a34a;
      --ok-soft: #e7f7ed;
      --warn: #d97706;
      --warn-soft: #fff4e0;
      --err: #dc2626;
      --err-soft: #fdecec;
      --get: #16a34a;
      --post: #4f5bea;
      --put: #d97706;
      --patch: #9333ea;
      --delete: #dc2626;
      --shadow: 0 1px 2px rgba(16, 24, 40, .04), 0 6px 18px rgba(16, 24, 40, .05);
      --shadow-lg: 0 24px 64px rgba(16, 24, 40, .18);
    }
  }

  * { box-sizing: border-box; }
  html, body { margin: 0; }
  body {
    min-height: 100vh;
    background: var(--bg);
    color: var(--text);
    font-family: var(--sans);
    font-size: 14px;
    line-height: 1.5;
    -webkit-font-smoothing: antialiased;
  }
  body::before {
    content: "";
    position: fixed;
    inset: 0;
    pointer-events: none;
    background:
      radial-gradient(900px 520px at 12% -8%, var(--glow-1), transparent 60%),
      radial-gradient(800px 600px at 105% 110%, var(--glow-2), transparent 60%);
  }
  button { font: inherit; color: inherit; }
  ::selection { background: rgba(124, 140, 255, .35); }

  .shell { position: relative; display: grid; grid-template-columns: var(--side-w) minmax(0, 1fr); min-height: 100vh; transition: grid-template-columns .2s ease; }
  .shell.rail { --side-w: 76px; }

  /* ---------- 사이드바 ---------- */
  .side {
    position: sticky; top: 0; height: 100vh; overflow: hidden;
    display: flex; flex-direction: column; gap: 22px;
    padding: 22px 14px;
    background: var(--panel);
    backdrop-filter: blur(14px);
    border-right: 1px solid var(--border);
  }
  .brand { display: flex; align-items: center; gap: 11px; padding: 0 4px; }
  .logo {
    width: 34px; height: 34px; border-radius: 11px; flex: none;
    background: linear-gradient(135deg, var(--accent), var(--accent-2));
    color: #fff; font-weight: 800; font-size: 16px;
    display: grid; place-items: center;
    box-shadow: 0 6px 18px rgba(124, 140, 255, .35), inset 0 1px 0 rgba(255, 255, 255, .25);
  }
  .brand-name { font-size: 17px; font-weight: 800; letter-spacing: -.3px; }
  .brand-sub { font-size: 11.5px; color: var(--text-3); white-space: nowrap; }
  .rail-btn {
    margin-left: auto; width: 28px; height: 28px; border-radius: 8px; border: 0; flex: none;
    background: transparent; color: var(--text-3); cursor: pointer; display: grid; place-items: center;
  }
  .rail-btn:hover { background: var(--surface-3); color: var(--text); }

  .side-label { font-size: 11px; font-weight: 700; letter-spacing: .6px; color: var(--text-3); padding: 0 8px; margin-bottom: 8px; text-transform: uppercase; white-space: nowrap; }
  .nav { display: grid; gap: 4px; }
  .nav-item {
    position: relative; display: flex; align-items: center; gap: 11px;
    width: 100%; padding: 9px 10px; border: 0; border-radius: 12px;
    background: transparent; cursor: pointer; text-align: left;
    transition: background .15s;
  }
  .nav-item:hover { background: var(--field); }
  .nav-item.on { background: var(--accent-soft); }
  .nav-item.on::before {
    content: ""; position: absolute; left: -14px; top: 10px; bottom: 10px; width: 3px; border-radius: 0 3px 3px 0;
    background: linear-gradient(var(--accent), var(--accent-2));
  }
  .nav-icon {
    position: relative; width: 34px; height: 34px; border-radius: 10px; flex: none;
    display: grid; place-items: center;
    background: var(--surface-3); color: var(--text-2);
  }
  .nav-item.on .nav-icon { background: linear-gradient(135deg, var(--accent), var(--accent-2)); color: #fff; }
  .nav-text { min-width: 0; }
  .nav-text b { display: block; font-size: 13.5px; }
  .nav-text span { display: block; font: 11.5px var(--mono); color: var(--text-3); white-space: nowrap; }
  .nav-item.on .nav-text span { color: var(--accent-text); }
  .cnt {
    margin-left: auto; min-width: 20px; height: 20px; padding: 0 6px; border-radius: 999px;
    font: 700 11px var(--mono); display: grid; place-items: center;
    background: var(--err-soft); color: var(--err);
  }
  .cnt.zero { background: var(--ok-soft); color: var(--ok); }
  .nav-icon .dot-err { position: absolute; top: -3px; right: -3px; width: 10px; height: 10px; border-radius: 50%; background: var(--err); border: 2px solid var(--surface); display: none; }

  .conn { display: grid; gap: 6px; padding: 12px; border-radius: 12px; background: var(--field); border: 1px solid var(--border); font-size: 12.5px; }
  .conn-row { display: flex; align-items: center; gap: 8px; white-space: nowrap; }
  .conn-row .muted { color: var(--text-3); margin-left: auto; font: 11.5px var(--mono); }
  .dot { width: 8px; height: 8px; border-radius: 50%; background: var(--ok); box-shadow: 0 0 0 3px var(--ok-soft); flex: none; }
  .dot.live { animation: pulse 2.6s ease-in-out infinite; }
  @keyframes pulse { 50% { box-shadow: 0 0 0 6px var(--ok-soft); } }

  .shortcuts { display: grid; gap: 6px; padding: 12px; border-radius: 12px; background: var(--field); border: 1px solid var(--border); font-size: 11.5px; color: var(--text-2); }
  .shortcuts div { display: flex; justify-content: space-between; gap: 8px; white-space: nowrap; }
  kbd {
    font: 600 10.5px var(--mono); color: var(--text-2);
    padding: 2px 6px; border-radius: 6px;
    background: var(--surface-3); border: 1px solid var(--border-strong); border-bottom-width: 2px;
  }
  .side-foot { margin-top: auto; display: grid; gap: 6px; }
  .guard { display: flex; align-items: center; gap: 8px; font-size: 11.5px; color: var(--text-3); padding: 0 8px; white-space: nowrap; }
  .guard svg { color: var(--ok); flex: none; }

  .shell.rail .brand-text, .shell.rail .nav-text, .shell.rail .side-label, .shell.rail .conn,
  .shell.rail .shortcuts, .shell.rail .guard span, .shell.rail .cnt { display: none; }
  .shell.rail .brand { flex-direction: column; gap: 10px; }
  .shell.rail .rail-btn { margin: 0; transform: rotate(180deg); }
  .shell.rail .nav-item { justify-content: center; padding: 9px 0; }
  .shell.rail .nav-icon .dot-err.show { display: block; }
  .shell.rail .guard { justify-content: center; }

  /* ---------- 메인 ---------- */
  .main { min-width: 0; padding: 0 28px 48px; }
  .head {
    position: sticky; top: 0; z-index: 10;
    display: flex; align-items: flex-end; gap: 16px;
    margin: 0 -28px; padding: 22px 28px 14px;
    border-bottom: 1px solid transparent;
    transition: background .2s, border-color .2s;
  }
  .head.scrolled { background: var(--glass); backdrop-filter: blur(14px); border-bottom-color: var(--border); }
  .crumb { font: 12px var(--mono); color: var(--text-3); }
  .crumb i { font-style: normal; margin: 0 6px; opacity: .6; }
  .crumb b { color: var(--accent-text); font-weight: 600; }
  .title { margin: 4px 0 0; font-size: 24px; font-weight: 800; letter-spacing: -.6px; }
  .head-right { margin-left: auto; display: flex; align-items: center; gap: 8px; }
  .save {
    display: flex; align-items: center; gap: 8px;
    padding: 7px 13px; border-radius: 999px;
    background: var(--surface); border: 1px solid var(--border);
    box-shadow: var(--shadow); font-size: 12.5px; color: var(--text-2);
  }
  .save .spin { width: 12px; height: 12px; border-radius: 50%; border: 2px solid var(--warn-soft); border-top-color: var(--warn); animation: spin .7s linear infinite; display: none; }
  .save.busy .spin { display: block; }
  .save.busy .dot { display: none; }
  @keyframes spin { to { transform: rotate(360deg); } }

  .work { --pv-w: clamp(440px, 35vw, 580px); display: grid; grid-template-columns: minmax(0, 1fr) 14px max(440px, min(var(--pv-w), calc(100% - 574px))); align-items: start; padding-top: 6px; }
  .work.wide { grid-template-columns: minmax(0, 1fr); }
  .work.wide .preview, .work.wide .resizer { display: none; }
  .resizer { position: sticky; top: 92px; height: calc(100vh - 120px); cursor: col-resize; display: grid; place-items: center; }
  .resizer::after { content: ""; width: 4px; height: 44px; border-radius: 4px; background: var(--border-strong); transition: background .15s, height .15s; }
  .resizer:hover::after, .resizer.drag::after { background: var(--accent); height: 72px; }
  @media (max-width: 1180px) {
    .work { grid-template-columns: minmax(0, 1fr); }
    .resizer { display: none; }
    .preview { position: static !important; margin-top: 8px; }
  }
  @media (max-width: 860px) {
    .shell { grid-template-columns: 1fr; }
    .side { position: static; height: auto; }
    .main { padding: 0 16px 40px; }
    .head { margin: 0 -16px; padding: 18px 16px 12px; }
  }

  /* ---------- 카드 ---------- */
  .card { background: var(--surface); border: 1px solid var(--border); border-radius: 18px; box-shadow: var(--shadow); padding: 20px 20px 18px; margin-bottom: 18px; }
  .card-head { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 14px; }
  .card-title { margin: 0; font-size: 15.5px; font-weight: 800; letter-spacing: -.3px; display: flex; align-items: center; gap: 8px; }
  .card-title .count { font: 600 11px var(--mono); color: var(--text-3); background: var(--surface-3); padding: 2px 7px; border-radius: 999px; }
  .card-desc { margin: 3px 0 0; font-size: 12.5px; color: var(--text-3); }
  .card-tools { margin-left: auto; display: flex; align-items: center; gap: 8px; flex: none; }
  .ghost {
    display: inline-flex; align-items: center; gap: 6px;
    border: 1px solid var(--border); background: transparent; color: var(--text-2);
    padding: 6px 10px; border-radius: 9px; cursor: pointer; font-size: 12px;
  }
  .ghost:hover, .ghost.on { border-color: var(--accent); color: var(--accent-text); background: var(--accent-soft); }
  .guide { display: none; margin: -4px 0 14px; padding: 12px 14px; border-radius: 12px; background: var(--field); border: 1px solid var(--border); color: var(--text-2); font: 12px/1.65 var(--mono); white-space: pre-wrap; }
  .guide.show { display: block; }
  .empty-hint {
    display: flex; align-items: center; gap: 10px; margin-bottom: 12px;
    padding: 12px 14px; border-radius: 12px; font-size: 12.5px; color: var(--text-2);
    background: var(--accent-soft); border: 1px dashed color-mix(in srgb, var(--accent) 45%, transparent);
  }

  .row { display: grid; grid-template-columns: 240px minmax(0, 1fr) auto 32px; gap: 8px; align-items: center; margin-bottom: 8px; }
  .row .label { font-size: 12.5px; font-weight: 700; color: var(--text-2); padding-left: 2px; }
  .input {
    width: 100%; height: 38px; padding: 0 12px;
    border: 1px solid var(--border); border-radius: 11px;
    background: var(--field); color: var(--text);
    font: inherit; font-size: 13.5px; outline: none;
    transition: border-color .15s, box-shadow .15s, background .15s;
  }
  .input::placeholder { color: var(--text-3); }
  .input:hover { border-color: var(--border-strong); }
  .input:focus { border-color: var(--accent); box-shadow: 0 0 0 4px var(--accent-soft); background: var(--surface); }
  .mono { font-family: var(--mono); font-size: 12.8px; }
  textarea.input { height: auto; min-height: 72px; padding: 10px 12px; resize: none; line-height: 1.65; overflow: hidden; }

  .picker {
    display: flex; align-items: center; gap: 8px; width: 100%; height: 38px; padding: 0 10px 0 12px;
    border: 1px solid var(--border); border-radius: 11px; background: var(--field);
    cursor: pointer; text-align: left; font-size: 13px; font-family: var(--mono);
    transition: border-color .15s, box-shadow .15s;
  }
  .picker:hover { border-color: var(--border-strong); }
  .picker.open, .picker:focus-visible { outline: none; border-color: var(--accent); box-shadow: 0 0 0 4px var(--accent-soft); }
  .picker.empty .picker-val { color: var(--text-3); font-family: var(--sans); }
  .picker-val { flex: 1; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .picker .grp { font: 700 10px var(--sans); color: var(--text-3); background: var(--surface-3); padding: 2px 6px; border-radius: 6px; flex: none; }
  .picker svg { color: var(--text-3); flex: none; }

  .pop {
    position: fixed; z-index: 70; display: none; width: 300px; max-height: 360px;
    background: var(--surface); border: 1px solid var(--border-strong); border-radius: 14px;
    box-shadow: var(--shadow-lg); overflow: hidden; animation: pop .14s ease-out;
  }
  .pop.show { display: flex; flex-direction: column; }
  .pop-search { margin: 8px; height: 34px; border: 1px solid var(--border); border-radius: 9px; background: var(--field); color: var(--text); padding: 0 10px; font: 13px var(--sans); outline: none; }
  .pop-search:focus { border-color: var(--accent); }
  .pop-list { overflow: auto; padding: 0 6px 6px; }
  .pop-grp { font-size: 10.5px; font-weight: 800; letter-spacing: .6px; color: var(--text-3); padding: 8px 8px 4px; text-transform: uppercase; }
  .opt {
    display: flex; align-items: center; gap: 8px; width: 100%; padding: 7px 8px; border: 0; border-radius: 8px;
    background: transparent; cursor: pointer; text-align: left; font: 12.8px var(--mono); color: var(--text);
  }
  .opt:hover:not(:disabled), .opt.cur { background: var(--accent-soft); color: var(--accent-text); }
  .opt:disabled { color: var(--text-3); cursor: default; }
  .opt small { margin-left: auto; font: 11px var(--sans); color: var(--text-3); }
  .pop-empty { padding: 14px; font-size: 12.5px; color: var(--text-3); }

  .badge { display: inline-flex; align-items: center; gap: 6px; font-size: 11.5px; font-weight: 700; padding: 5px 10px; border-radius: 999px; white-space: nowrap; justify-self: start; }
  .badge::before { content: ""; width: 6px; height: 6px; border-radius: 50%; background: currentColor; }
  .badge.ok { background: var(--ok-soft); color: var(--ok); }
  .badge.warn { background: var(--warn-soft); color: var(--warn); }
  .badge.err { background: var(--err-soft); color: var(--err); }
  .badge.neutral { background: var(--surface-3); color: var(--text-3); }
  .badge.hide { display: none; }

  .seg { display: inline-flex; padding: 3px; border-radius: 11px; background: var(--field); border: 1px solid var(--border); }
  .seg button { border: 0; background: transparent; color: var(--text-3); padding: 5px 12px; border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 700; }
  .seg button.on { background: var(--surface-3); color: var(--text); box-shadow: 0 1px 2px rgba(0, 0, 0, .2); }

  .item {
    position: relative; display: grid; grid-template-columns: 30px minmax(0, 1fr); gap: 14px;
    padding: 14px 14px 14px 16px; margin-bottom: 12px;
    border: 1px solid var(--border); border-radius: 14px;
    background: linear-gradient(180deg, rgba(255, 255, 255, .02), transparent 60%), var(--surface);
    transition: border-color .15s, box-shadow .15s;
  }
  .item::before { content: ""; position: absolute; left: -1px; top: 14px; bottom: 14px; width: 3px; border-radius: 0 3px 3px 0; background: var(--c, linear-gradient(var(--accent), var(--accent-2))); }
  .item:focus-within { border-color: var(--border-strong); box-shadow: 0 0 0 4px var(--accent-soft); }
  .item.enter { animation: pop .22s ease-out; }
  .item.collapsed { padding-top: 9px; padding-bottom: 9px; align-items: center; }
  .item.collapsed .num { margin-top: 0; }
  .num { width: 30px; height: 30px; border-radius: 50%; display: grid; place-items: center; margin-top: 4px; background: linear-gradient(135deg, var(--accent), var(--accent-2)); color: #fff; font-weight: 800; font-size: 13px; box-shadow: 0 4px 12px rgba(124, 140, 255, .3); }
  .num.free { background: var(--surface-3); color: var(--text-3); box-shadow: none; }
  .item-body { display: grid; gap: 10px; min-width: 0; }
  .item-head { display: flex; align-items: center; gap: 8px; min-width: 0; flex-wrap: wrap; }
  .w-proj { width: 230px; flex: none; }
  .grow { flex: 1; min-width: 160px; }
  .tools { margin-left: auto; display: flex; gap: 2px; flex: none; }
  .icon-btn { width: 30px; height: 30px; border: 0; border-radius: 9px; background: transparent; color: var(--text-3); cursor: pointer; display: grid; place-items: center; transition: background .12s, color .12s; }
  .icon-btn:hover:not(:disabled) { background: var(--surface-3); color: var(--text); }
  .icon-btn.danger:hover { background: var(--err-soft); color: var(--err); }
  .icon-btn:disabled { opacity: .25; cursor: default; }
  .sum { display: flex; align-items: center; gap: 10px; flex: 1; min-width: 0; border: 0; background: transparent; cursor: pointer; text-align: left; padding: 5px 8px; border-radius: 9px; }
  .sum:hover { background: var(--field); }
  .sum-title { font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; min-width: 0; }
  .sum-api { font: 600 12.5px var(--mono); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; min-width: 0; }
  .sum-proj { font: 11.5px var(--mono); color: var(--text-3); white-space: nowrap; flex: none; }

  .methods { display: inline-flex; gap: 3px; padding: 3px; border-radius: 11px; background: var(--field); border: 1px solid var(--border); }
  .m { display: inline-flex; align-items: center; gap: 6px; border: 0; background: transparent; color: var(--text-3); padding: 5px 9px; border-radius: 8px; cursor: pointer; font: 700 11px var(--mono); letter-spacing: .4px; }
  .m::before { content: ""; width: 6px; height: 6px; border-radius: 50%; background: var(--mc); opacity: .5; }
  .m:hover { color: var(--text); }
  .m.on { color: var(--mc); background: color-mix(in srgb, var(--mc) 16%, transparent); }
  .m.on::before { opacity: 1; box-shadow: 0 0 8px var(--mc); }

  .api { display: flex; align-items: center; gap: 8px; min-width: 0; padding: 0 6px 0 4px; height: 40px; border-radius: 11px; background: var(--field); border: 1px solid var(--border); transition: border-color .15s, box-shadow .15s; }
  .api:focus-within { border-color: var(--accent); box-shadow: 0 0 0 4px var(--accent-soft); }
  .api-m { font: 800 11px var(--mono); letter-spacing: .5px; color: var(--c); background: color-mix(in srgb, var(--c) 15%, transparent); padding: 6px 9px; border-radius: 8px; flex: none; }
  .api input { flex: 1; min-width: 0; height: 100%; border: 0; background: transparent; color: var(--text); outline: none; font: 13px var(--mono); }
  .api input::placeholder { color: var(--text-3); }
  .refs { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
  .refs-label { font-size: 11.5px; color: var(--text-3); margin-right: 2px; }
  .chip { border: 1px dashed var(--border-strong); background: transparent; color: var(--text-2); border-radius: 8px; padding: 5px 8px; font: 11.5px var(--mono); cursor: pointer; white-space: nowrap; flex: none; }
  .chip:hover { border-color: var(--t-ref); color: var(--t-ref); }

  .code-ed { border-radius: 12px; overflow: hidden; border: 1px solid var(--border); background: var(--code-bg); transition: border-color .15s, box-shadow .15s; }
  .code-ed:focus-within { border-color: var(--accent); box-shadow: 0 0 0 4px var(--accent-soft); }
  .code-top { display: flex; align-items: center; gap: 8px; padding: 7px 10px 7px 14px; background: var(--code-head); border-bottom: 1px solid rgba(255, 255, 255, .05); }
  .code-label { font: 700 11px var(--mono); letter-spacing: .4px; color: #8a94b3; }
  .code-top .badge { margin-left: auto; }
  .mini { display: inline-flex; align-items: center; gap: 5px; border: 1px solid rgba(255, 255, 255, .1); background: transparent; color: #a9b1d6; padding: 4px 8px; border-radius: 7px; cursor: pointer; font-size: 11.5px; white-space: nowrap; }
  .mini:hover { border-color: var(--accent); color: #fff; }
  .rt { font: 700 10.5px var(--mono); letter-spacing: .3px; padding: 3px 8px; border-radius: 999px; }
  .rt.js { color: var(--t-key); background: rgba(122, 162, 247, .13); }
  .rt.q { color: var(--t-str); background: rgba(158, 206, 106, .13); }
  .rt.mp { color: #f7768e; background: rgba(247, 118, 142, .13); }
  .code-box { display: flex; }
  .gutter { flex: none; width: 40px; padding: 10px 8px 10px 0; text-align: right; font: 12.5px/1.7 var(--mono); color: var(--code-no); user-select: none; background: rgba(255, 255, 255, .015); border-right: 1px solid rgba(255, 255, 255, .04); }
  .gutter span { display: block; }
  .gutter span.err { color: #f7768e; font-weight: 700; }
  .code-area { position: relative; flex: 1; min-width: 0; }
  .code-hl, .code-ta { margin: 0; padding: 10px 14px; border: 0; font: 12.5px/1.7 var(--mono); tab-size: 2; white-space: pre-wrap; word-break: break-word; }
  .code-hl { min-height: 92px; color: var(--code-text); pointer-events: none; }
  .code-ta { position: absolute; inset: 0; width: 100%; height: 100%; background: transparent; color: transparent; caret-color: #e6e9ff; resize: none; outline: none; overflow: hidden; }
  .code-ta::placeholder { color: var(--code-dim); }
  .t-key { color: var(--t-key); }
  .t-str { color: var(--t-str); }
  .t-num { color: var(--t-num); }
  .t-bool { color: var(--t-bool); }
  .t-br { color: var(--t-br); }
  .t-pun { color: var(--t-pun); }
  .t-ref { color: var(--t-ref); background: rgba(224, 175, 104, .14); border-radius: 4px; }
  .t-ref.todo { color: #ff9e64; background: rgba(255, 158, 100, .18); outline: 1px dashed rgba(255, 158, 100, .6); }
  .t-mp { color: #f7768e; background: rgba(247, 118, 142, .14); border-radius: 4px; }
  .files { display: grid; gap: 6px; padding: 8px 14px 10px; border-top: 1px solid rgba(255, 255, 255, .04); }
  .files:empty { display: none; }
  .file-row { display: flex; align-items: center; gap: 10px; font: 12px var(--mono); color: #a9b1d6; min-width: 0; }
  .file-row .k { color: var(--t-key); flex: none; }
  .file-row .p { color: #f7768e; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; }
  .code-help { display: flex; align-items: center; gap: 12px; justify-content: space-between; flex-wrap: wrap; padding: 6px 14px; font-size: 11px; border-top: 1px solid rgba(255, 255, 255, .04); }
  .qs { color: #9ece6a; font-family: var(--mono); word-break: break-all; }
  .qs:empty { display: none; }
  .keys { color: #59617d; }

  .add { display: flex; align-items: center; justify-content: center; gap: 7px; width: 100%; height: 42px; margin-top: 2px; border: 1.5px dashed var(--border-strong); border-radius: 13px; background: transparent; color: var(--text-2); cursor: pointer; font-size: 13px; font-weight: 700; transition: all .15s; }
  .add:hover { border-color: var(--accent); color: var(--accent-text); background: var(--accent-soft); }
  .token { display: flex; align-items: center; height: 38px; border: 1px solid var(--border); border-radius: 11px; background: var(--field); overflow: hidden; }
  .token:focus-within { border-color: var(--accent); box-shadow: 0 0 0 4px var(--accent-soft); }
  .token .bearer { padding: 0 11px; height: 100%; display: grid; place-items: center; font: 700 11.5px var(--mono); color: var(--md-a); border-right: 1px solid var(--border); }
  .token input { flex: 1; min-width: 0; height: 100%; border: 0; background: transparent; color: var(--text); outline: none; padding: 0 12px; font: 13px var(--mono); }

  /* ---------- 미리보기 ---------- */
  .preview { position: sticky; top: 92px; border-radius: 18px; overflow: hidden; background: var(--code-bg); border: 1px solid rgba(255, 255, 255, .06); box-shadow: var(--shadow-lg); }
  .pv-head { display: flex; align-items: center; gap: 10px; padding: 11px 14px; background: var(--code-head); border-bottom: 1px solid rgba(255, 255, 255, .05); }
  .lights { display: flex; gap: 6px; }
  .lights i { width: 10px; height: 10px; border-radius: 50%; display: block; }
  .lights i:nth-child(1) { background: #f7768e; }
  .lights i:nth-child(2) { background: #e0af68; }
  .lights i:nth-child(3) { background: #9ece6a; }
  .pv-file { font: 600 12px var(--mono); color: #c0caf5; }
  .pv-meta { font: 11px var(--mono); color: #59617d; }
  .pv-head .mini { margin-left: auto; }
  .pv-body { position: relative; padding: 12px 0 16px; max-height: calc(100vh - 190px); overflow: auto; font: 12.3px/1.75 var(--mono); color: var(--code-text); }
  .pl { display: flex; padding-right: 16px; }
  .pl:hover { background: rgba(255, 255, 255, .025); }
  .pl.hot { background: rgba(122, 162, 247, .10); box-shadow: inset 2px 0 0 var(--t-key); }
  .pl.hot .no { color: var(--t-key); }
  .pl .no { flex: none; width: 44px; padding-right: 14px; text-align: right; color: var(--code-no); user-select: none; }
  .pl .tx { flex: 1; min-width: 0; white-space: pre-wrap; word-break: break-word; }
  .pv-body .h { color: var(--md-h); font-weight: 700; }
  .pv-body .c { color: var(--code-dim); }
  .pv-body .fold { cursor: pointer; border-bottom: 1px dotted var(--code-dim); }
  .pv-body .fold:hover { color: #8a94b3; }
  .pv-body .n { color: var(--md-n); font-weight: 700; }
  .pv-body .p { color: var(--md-p); }
  .pv-body .a { color: var(--md-a); }
  .pv-body .d { color: #c0caf5; }
  .pv-foot { display: flex; gap: 8px; align-items: center; padding: 10px 14px; border-top: 1px solid rgba(255, 255, 255, .05); font-size: 11.5px; color: #59617d; }

  /* ---------- 모달·토스트 ---------- */
  .backdrop { position: fixed; inset: 0; z-index: 50; display: none; place-items: center; background: rgba(6, 8, 12, .55); backdrop-filter: blur(4px); }
  .backdrop.show { display: grid; animation: fade .15s ease-out; }
  @keyframes fade { from { opacity: 0; } }
  .modal { width: min(780px, calc(100vw - 32px)); max-height: calc(100vh - 48px); overflow: auto; background: var(--surface); border: 1px solid var(--border); border-radius: 20px; box-shadow: var(--shadow-lg); padding: 24px; animation: pop .18s ease-out; transition: width .32s cubic-bezier(.2, .8, .2, 1); }
  .modal.large { width: min(1280px, calc(100vw - 32px)); }
  .modal.large .diff pre { max-height: max(240px, calc(100vh - 360px)); }
  /* 넓어지고 줄어드는 동안은 스크롤바를 숨김 (폭이 줄며 줄바꿈이 늘 때 잠깐 뜨는 것 방지) */
  .modal.anim, .modal.anim .diff pre { overflow: hidden; }
  @keyframes pop { from { transform: translateY(8px) scale(.98); opacity: 0; } }
  .modal-head { display: flex; gap: 14px; align-items: flex-start; margin-bottom: 18px; }
  .modal-icon { width: 40px; height: 40px; border-radius: 12px; flex: none; display: grid; place-items: center; background: var(--warn-soft); color: var(--warn); font-weight: 800; font-size: 18px; }
  .modal h3 { margin: 0 0 4px; font-size: 17px; letter-spacing: -.3px; }
  .modal p { margin: 0; color: var(--text-2); font-size: 13px; }
  .stamps { display: flex; gap: 8px; margin-top: 10px; flex-wrap: wrap; }
  .stamp { font: 11.5px var(--mono); padding: 4px 9px; border-radius: 999px; background: var(--surface-3); color: var(--text-2); }
  .stamp.new { background: var(--ok-soft); color: var(--ok); font-weight: 700; }
  .choices { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
  .choice { text-align: left; padding: 14px; border-radius: 14px; cursor: pointer; border: 1px solid var(--border); background: var(--field); transition: all .15s; }
  .choice:hover { border-color: var(--accent); background: var(--accent-soft); transform: translateY(-1px); }
  .choice b { display: block; font-size: 13.5px; margin-bottom: 3px; }
  .choice span { font-size: 12px; color: var(--text-3); }
  /* 비교 영역: 높이(0fr→1fr)와 팝업 폭을 같은 속도로 늘리고, 내용은 조금 늦게 나타나게 */
  .diff { display: grid; grid-template-rows: 0fr; opacity: 0; visibility: hidden; transition: grid-template-rows .32s cubic-bezier(.2, .8, .2, 1), opacity .16s ease, visibility 0s linear .32s; }
  .diff.show { grid-template-rows: 1fr; opacity: 1; visibility: visible; transition: grid-template-rows .32s cubic-bezier(.2, .8, .2, 1), opacity .22s ease .1s, visibility 0s; }
  .diff-in { min-height: 0; overflow: hidden; }
  .diff-cols { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; padding-top: 14px; }
  .diff h4 { margin: 0 0 6px; font-size: 12px; color: var(--text-3); }
  .diff pre { margin: 0; padding: 12px; border-radius: 12px; background: var(--code-bg); color: var(--code-text); font: 11.5px/1.7 var(--mono); white-space: pre-wrap; max-height: 300px; overflow: auto; }
  .diff .mine { display: block; background: rgba(247, 118, 142, .14); }
  .diff .theirs { display: block; background: rgba(158, 206, 106, .14); }
  .diff .ln { display: block; }
  .modal-foot { display: flex; justify-content: flex-end; margin-top: 16px; }
  .modal-note { font-size: 12px; color: var(--text-3); }
  .toasts { position: fixed; right: 24px; bottom: 24px; z-index: 80; display: grid; gap: 10px; }
  .toast { display: flex; align-items: center; gap: 12px; max-width: 540px; padding: 12px 14px; border-radius: 14px; font-size: 13px; background: rgba(24, 28, 38, .92); color: #eef1f8; backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, .08); box-shadow: var(--shadow-lg); animation: pop .2s ease-out; }
  .ro-note { padding: 18px 20px; border-radius: 14px; border: 1px solid var(--err); background: var(--err-soft); color: var(--text); font-size: 13.5px; line-height: 1.7; }
  .ro-note b { color: var(--err); }
  .dot.off { background: var(--err); box-shadow: 0 0 0 3px var(--err-soft); animation: none; }
  .toast button { margin-left: auto; border: 1px solid rgba(255, 255, 255, .2); background: transparent; color: #fff; border-radius: 8px; padding: 4px 10px; cursor: pointer; font-size: 12px; white-space: nowrap; }
</style>
</head>
<body>
<div class="shell" id="shell">

  <aside class="side">
    <div class="brand">
      <div class="logo">E</div>
      <div class="brand-text">
        <div class="brand-name">Editor</div>
        <div class="brand-sub">.claude 명세 편집</div>
      </div>
      <button class="rail-btn" data-act="rail" title="사이드바 접기·펼치기"><svg viewBox="0 0 16 16" width="15" height="15" aria-hidden="true"><path d="M10 3.5L5.5 8l4.5 4.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
    </div>

    <div>
      <div class="side-label">파일</div>
      <nav class="nav">
        <button class="nav-item on" data-act="tab" data-v="task" title="TASK">
          <span class="nav-icon"><svg viewBox="0 0 16 16" width="17" height="17" aria-hidden="true"><path d="M4 1.8h5.2L12.5 5v9.2H4z" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M6 8h4.5M6 10.6h4.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg><i class="dot-err" id="dot-task"></i></span>
          <span class="nav-text"><b>TASK</b><span>task/TASK.md</span></span>
          <span class="cnt" id="cnt-task">0</span>
        </button>
        <button class="nav-item" data-act="tab" data-v="test" title="TEST">
          <span class="nav-icon"><svg viewBox="0 0 16 16" width="17" height="17" aria-hidden="true"><path d="M6 1.8h4M6.6 1.8v4.4L3 12.6a1.2 1.2 0 0 0 1 1.8h8a1.2 1.2 0 0 0 1-1.8L9.4 6.2V1.8" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M4.6 10h6.8" stroke="currentColor" stroke-width="1.4"/></svg><i class="dot-err" id="dot-test"></i></span>
          <span class="nav-text"><b>TEST</b><span>test/TEST.md</span></span>
          <span class="cnt" id="cnt-test">0</span>
        </button>
      </nav>
    </div>

    <div class="conn-wrap">
      <div class="side-label">연결</div>
      <div class="conn">
        <div class="conn-row"><span class="dot live" id="st-dot"></span><b id="st-file">TASK.md</b><span class="muted" id="st-time">--:--:--</span></div>
        <div class="conn-row" id="st-conn" style="color:var(--text-3);font-size:11.5px">연결 중…</div>
      </div>
    </div>

    <div>
      <div class="side-label">단축키</div>
      <div class="shortcuts">
        <div><span>JSON 정렬</span><span><kbd>Ctrl</kbd> <kbd>Alt</kbd> <kbd>L</kbd></span></div>
        <div><span>들여쓰기</span><span><kbd>Tab</kbd> <kbd>⇧Tab</kbd></span></div>
        <div><span>되돌리기</span><span><kbd>Ctrl</kbd> <kbd>Z</kbd></span></div>
        <div><span>선택 창 닫기</span><span><kbd>Esc</kbd></span></div>
      </div>
    </div>

    <div class="side-foot">
      <div class="guard" title="127.0.0.1 전용"><svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true"><path d="M3.5 8.5l3 3 6-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg><span>127.0.0.1 전용</span></div>
      <div class="guard" title="TASK.md · TEST.md만 읽고 씀"><svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true"><path d="M3.5 8.5l3 3 6-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg><span>md 2개만 읽고 씀</span></div>
      <div class="guard" title="워크스페이스 폴더 이름만 읽음"><svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true"><path d="M3.5 8.5l3 3 6-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg><span>폴더는 이름만 읽음</span></div>
      <div class="guard" title="브라우저 저장 없음"><svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true"><path d="M3.5 8.5l3 3 6-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg><span>브라우저 저장 없음</span></div>
    </div>
  </aside>

  <main class="main">
    <header class="head" id="head">
      <div>
        <div class="crumb">.claude<i>/</i><span id="crumb-dir">task</span><i>/</i><b id="crumb-file">TASK.md</b></div>
        <h1 class="title" id="page-title">작업 명세</h1>
      </div>
      <div class="head-right">
        <button class="ghost on" data-act="preview" title="md 미리보기 열기·닫기">미리보기</button>
        <div class="save" id="save"><span class="dot"></span><span class="spin"></span><span id="save-text">저장됨</span></div>
      </div>
    </header>

    <div class="work" id="work">
      <div id="form"></div>
      <div class="resizer" id="resizer" title="드래그해서 미리보기 폭 조절"></div>
      <aside class="preview" aria-label="md 미리보기">
        <div class="pv-head">
          <div class="lights"><i></i><i></i><i></i></div>
          <span class="pv-file" id="pv-file">TASK.md</span>
          <span class="pv-meta" id="pv-lines"></span>
          <button class="mini" data-act="fold" id="pv-fold">안내 펼치기</button>
        </div>
        <div class="pv-body" id="preview"></div>
        <div class="pv-foot"><span class="dot"></span>md에 실제로 저장되는 내용 · 템플릿 형식 그대로</div>
      </aside>
    </div>
  </main>
</div>

<div class="pop" id="pop" role="listbox">
  <input class="pop-search" id="pop-search" placeholder="프로젝트 검색" autocomplete="off" spellcheck="false">
  <div class="pop-list" id="pop-list"></div>
</div>

<div class="backdrop" id="modal" role="dialog" aria-modal="true" aria-labelledby="modal-heading">
  <div class="modal" id="conflict-box">
    <div class="modal-head">
      <div class="modal-icon">!</div>
      <div>
        <h3 id="modal-heading"></h3>
        <p id="modal-desc"></p>
        <div class="stamps"><span class="stamp" id="stamp-mine"></span><span class="stamp new" id="stamp-theirs"></span></div>
      </div>
    </div>
    <div class="choices">
      <button class="choice" data-act="modal-keep"><b>내 작성 유지</b><span>화면 내용으로 md를 덮어씁니다</span></button>
      <button class="choice" data-act="modal-load"><b>md 불러오기</b><span>md 내용으로 화면을 바꿉니다. 쓰던 내용은 버립니다</span></button>
      <button class="choice" data-act="modal-diff"><b>비교하기</b><span>두 내용을 나란히 봅니다</span></button>
    </div>
    <div class="diff" id="diff">
      <div class="diff-in">
        <div class="diff-cols">
          <div><h4>화면 (내 작성)</h4><pre id="diff-mine"></pre></div>
          <div><h4>md 파일 (바뀐 내용)</h4><pre id="diff-theirs"></pre></div>
        </div>
      </div>
    </div>
    <div class="modal-foot"><span class="modal-note">둘 중 하나를 고르면 닫힙니다 · 고를 때까지 자동 저장 멈춤</span></div>
  </div>
</div>

<div class="toasts" id="toasts"></div>

<script>
(function () {
  'use strict';

  var GUIDE = {
    task1: [
      '  작업 대상 프로젝트와 브랜치명 명시. 협업이 필요한 경우 모두 명시.',
      '',
      '  브랜치 명명규칙: issue-사업도메인약어-두레이번호',
      '',
      '  예) cyclepay-api: issue-domain-1234',
      '',
      '  단, 시작 전에 확인해서 존재하지 않는 프로젝트나 빠진 브랜치가 하나라도 있으면 전체 작업 불가. **형님**께 즉시 보고.'
    ].join('\n'),
    task2: [
      '  표기 방식: [프로젝트명] 개요',
      '',
      '  개요와 무엇을 어떻게 해야 하는지 상세하게 기술한다.',
      '',
      '  협업이 필요한 경우 번호를 붙여 순서와 의존관계를 기술한다.',
      '  - 순번 있음 → 연관 작업, 완료 후 다음 진행 (1요청 1작업)',
      '  - 순번 없음 → 독립 작업 (1요청 N작업)',
      '',
      '  예시)',
      '  [cyclepay-api] 결제 환불기능 추가',
      '  - api는 PATCH /v1/payments로 생성',
      '',
      '  1. [cyclepay-api] 결제 도메인에 환불 기능 추가',
      '  - api는 PATCH /v1/payments로 생성',
      '  2. [cyclepay-batch] 환불 배치 Job 추가',
      '  - 현시점기준 -1Day까지의 결제실패 데이터 조회',
      '  - 1번 작업 완료 후 환불요청 데이터 전문에 맞춰 환불요청'
    ].join('\n'),
    test1: [
      '  테스트 대상 프로젝트와 호스트 명시. 여러 프로젝트인 경우 모두 명시.',
      '  개발/운영 환경인 경우 Authorization Bearer Token 함께 명시.',
      '',
      '  예) cyclepay-api: http://localhost:9080',
      '      cyclepay-authorization: http://localhost:9081',
      '',
      '  개발/운영 예시)',
      '  Authorization: Bearer {token}',
      '  cyclepay-api: https://dev-api.cyclepay.kr',
      '',
      '  단, 시작 전에 확인해서 존재하지 않는 프로젝트나 빠진 호스트가 하나라도 있으면 전체 테스트 불가. **형님**께 즉시 보고.'
    ].join('\n'),
    test2: [
      '  표기 방식: [프로젝트명] Method + API + { 데이터 }',
      '',
      '  데이터는 JSON 형태로 통일.',
      '  단, 시작 전에 확인해서 JSON 형식이 아닌 데이터가 하나라도 있으면 전체 테스트 불가. **형님**께 즉시 보고.',
      '',
      '  Content-Type은 **짱구**가 메소드와 데이터를 보고 알아서 판단한다.',
      '  - GET, DELETE → querystring (Content-Type 불필요)',
      '  - POST, PUT, PATCH → application/json',
      '  - multipart 필드 있으면 → multipart/form-data, 해당 필드에 (multipart) 표기',
      '',
      '  여러 테스트인 경우 번호를 붙여 순서와 의존관계를 기술한다.',
      '  - 순번 있음 → 연관 테스트, 완료 후 다음 진행 (1요청 1작업)',
      '  - 순번 없음 → 독립 테스트 (1요청 N작업)',
      '',
      '  예시)',
      '  [cyclepay-api] POST /v1/files',
      '  {',
      '    "file": "/path/to/file.jpg (multipart)",',
      '    "name": "테스트"',
      '  }',
      '',
      '  1. [cyclepay-api] POST /v1/payments { "amount": 1000, "method": "PM01" }',
      '  2. [cyclepay-api] GET /v1/payments/{1번 응답 id}',
      '  3. [cyclepay-auth] PATCH /v1/tokens { "id": "{1번 응답 id}", "status": "PM02" }'
    ].join('\n')
  };

  /* 워크스페이스 루트의 폴더 이름 (켤 때 서버에서 받음) */
  var WORKSPACE = [];
  /* 서버가 화면에 심어 주는 접속 토큰 (다른 사이트에서 저장 요청을 못 보내게) */
  var TOKEN = '__TOKEN__';

  var METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'];
  var FILES = { task: 'TASK.md', test: 'TEST.md' };
  var TITLES = { task: '작업 명세', test: '테스트 명세' };
  var PAIRS = { '{': '}', '[': ']', '"': '"' };
  var FIELD = '필드';

  var ICON = {
    up: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M4 10l4-4 4 4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    down: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M4 6l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    x: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M4.5 4.5l7 7M11.5 4.5l-7 7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    plus: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M8 3.5v9M3.5 8h9" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
    eye: '<svg viewBox="0 0 16 16" width="15" height="15" aria-hidden="true"><path d="M1.5 8s2.4-4.5 6.5-4.5S14.5 8 14.5 8s-2.4 4.5-6.5 4.5S1.5 8 1.5 8z" fill="none" stroke="currentColor" stroke-width="1.4"/><circle cx="8" cy="8" r="2" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>',
    wand: '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><path d="M2.5 13.5l7-7M9.5 2v2M12.5 3.5l-1.4 1.4M14 6.5h-2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    book: '<svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true"><path d="M2.5 3.2c1.8-.8 3.7-.8 5.5.4 1.8-1.2 3.7-1.2 5.5-.4v9.6c-1.8-.8-3.7-.8-5.5.4-1.8-1.2-3.7-1.2-5.5-.4z M8 3.6v9.6" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/></svg>',
    copy: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><rect x="5.5" y="5.5" width="8" height="8" rx="1.8" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M10.5 3.5V3A1.5 1.5 0 0 0 9 1.5H4A1.5 1.5 0 0 0 2.5 3v5A1.5 1.5 0 0 0 4 9.5h.5" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>',
    collapse: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M4.5 2.5L8 6l3.5-3.5M4.5 13.5L8 10l3.5 3.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    expand: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M4.5 6L8 2.5 11.5 6M4.5 10L8 13.5l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    chev: '<svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true"><path d="M4 6l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    clip: '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><path d="M10.5 4.5l-5 5a1.4 1.4 0 0 0 2 2l5.5-5.5a2.8 2.8 0 0 0-4-4L3.5 7.5a4.2 4.2 0 0 0 6 6l4-4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>'
  };

  var seq = 0;
  function nid() { seq += 1; return 'u' + seq; }

  function emptyTab(tab) {
    return tab === 'task'
      ? { projects: [{ project: '', branch: '' }], ordered: true, items: [{ uid: nid(), project: '', title: '', detail: '' }] }
      : { hosts: [{ project: '', host: '' }], token: '', ordered: true, items: [{ uid: nid(), project: '', method: 'GET', api: '', body: '' }] };
  }

  var state = { task: emptyTab('task'), test: emptyTab('test') };
  /* md 파일과 맞춘 상태: base = 마지막으로 읽거나 쓴 md 버전, rev = 화면 변경 횟수, saved = 저장된 rev */
  function syncOf() { return { ok: false, error: '불러오는 중', raw: '', base: null, guides: [], rev: 0, saved: 0, inflight: false, again: false, editedAt: null }; }
  var sync = { task: syncOf(), test: syncOf() };
  var ui = { tab: 'task', showToken: false, foldGuide: true, guides: {}, preview: true, collapsed: {}, focusUid: null, scrollHot: false, enter: null, rail: false, railNarrow: true, conflict: null };
  var pick = { path: null, mode: null, button: null, q: '' };
  var fileTarget = null;

  var $ = function (sel) { return document.querySelector(sel); };
  var form = $('#form');

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function getPath(path) { return path.split('.').reduce(function (o, k) { return o == null ? o : o[k]; }, state); }
  function setPath(path, value) {
    var keys = path.split('.');
    var last = keys.pop();
    keys.reduce(function (o, k) { return o[k]; }, state)[last] = value;
  }
  function clock(at) {
    var d = at || new Date();
    return [d.getHours(), d.getMinutes(), d.getSeconds()].map(function (n) { return String(n).padStart(2, '0'); }).join(':');
  }
  function groupOf(name) { var i = name.indexOf('-'); return i > 0 ? name.slice(0, i) : '기타'; }
  function chosen(tab) {
    var list = tab === 'task' ? state.task.projects : state.test.hosts;
    return list.map(function (x) { return (x.project || '').trim(); }).filter(Boolean);
  }

  /* ---------- 검증 ---------- */
  function jsonErrorLine(text) {
    if (!text.trim()) return 0;
    try { JSON.parse(text); return 0; } catch (e) {
      var m = /position (\d+)/.exec(e.message);
      if (m) return text.slice(0, +m[1]).split('\n').length;
      var l = /line (\d+)/.exec(e.message);
      return l ? +l[1] : text.split('\n').length;
    }
  }
  function check(kind, value, extra) {
    var v = (value || '').trim();
    switch (kind) {
      case 'branch':
        if (!v) return (extra || '').trim() ? ['warn', '브랜치 없음'] : ['neutral', '입력 대기'];
        return /^issue-[a-z0-9]+-\d+$/.test(v) ? ['ok', '규칙 맞음'] : ['warn', 'issue-도메인-번호'];
      case 'host':
        if (!v) return (extra || '').trim() ? ['warn', '호스트 없음'] : ['neutral', '입력 대기'];
        return /^https?:\/\/\S+$/.test(v) ? ['ok', '주소 정상'] : ['warn', 'http(s)://로 시작'];
      case 'api':
        if (!v) return ['neutral', '입력 대기'];
        return v.charAt(0) === '/' ? ['ok', '경로 정상'] : ['warn', '/로 시작'];
      case 'json':
        if (!v) return ['neutral', extra === 'GET' || extra === 'DELETE' ? '쿼리 없음' : '본문 없음'];
        var line = jsonErrorLine(value);
        return line ? ['err', 'JSON 오류 · ' + line + '행'] : ['ok', 'JSON 정상'];
      case 'inws':
        if (!v) return ['hide', ''];
        return WORKSPACE.indexOf(v) >= 0 ? ['hide', ''] : ['err', '워크스페이스에 없음'];
      case 'intarget':
      case 'inhost':
        if (!v) return ['neutral', '프로젝트 선택'];
        return chosen(kind === 'intarget' ? 'task' : 'test').indexOf(v) >= 0 ? ['hide', '']
          : ['err', kind === 'intarget' ? '대상에서 빠진 프로젝트' : '호스트 목록에 없음'];
    }
    return ['neutral', ''];
  }
  function checkRefs(it, idx) {
    var text = (it.api || '') + ' ' + (it.body || ''), re = /\{(\d+)번 응답 ?([^}]*)\}/g, m, any = false, bad = false, todo = false;
    while ((m = re.exec(text))) {
      any = true;
      if (+m[1] > idx || +m[1] < 1) bad = true;
      if (!m[2].trim() || m[2].trim() === FIELD) todo = true;
    }
    if (!any) return ['hide', ''];
    if (todo) return ['warn', '필드명 입력'];
    if (!state.test.ordered) return ['warn', '순번 없음인데 참조 있음'];
    return bad ? ['warn', '참조 번호 확인'] : ['hide', ''];
  }
  function toQuery(text) {
    var o;
    try { o = JSON.parse(text); } catch (e) { return null; }
    if (!o || typeof o !== 'object' || Array.isArray(o)) return null;
    var parts = [];
    Object.keys(o).forEach(function (k) {
      (Array.isArray(o[k]) ? o[k] : [o[k]]).forEach(function (x) {
        parts.push(k + '=' + (x !== null && typeof x === 'object' ? JSON.stringify(x) : String(x)));
      });
    });
    return parts.length ? '?' + parts.join('&') : '';
  }
  function requestType(it) {
    if (it.method === 'GET' || it.method === 'DELETE') return ['q', '쿼리스트링'];
    return /\(multipart\)/.test(it.body) ? ['mp', 'multipart/form-data'] : ['js', 'application/json'];
  }
  function fileFields(body) {
    var re = /"([^"]+)"\s*:\s*"([^"]*?)\s*\(multipart\)"/g, m, out = [];
    while ((m = re.exec(body))) out.push({ key: m[1], path: m[2] });
    return out;
  }
  function issueCount(tab) {
    if (!sync[tab].ok) return 1;
    var n = 0, s = state[tab], bad = function (r) { return r[0] === 'warn' || r[0] === 'err'; };
    if (tab === 'task') {
      s.projects.forEach(function (p) { if (bad(check('inws', p.project)) || bad(check('branch', p.branch, p.project))) n++; });
      s.items.forEach(function (it) { if (bad(check('intarget', it.project))) n++; });
    } else {
      s.hosts.forEach(function (h) { if (bad(check('inws', h.project)) || bad(check('host', h.host, h.project))) n++; });
      s.items.forEach(function (it, i) {
        if (bad(check('inhost', it.project)) || bad(check('api', it.api)) || bad(check('json', it.body, it.method)) || bad(checkRefs(it, i))) n++;
      });
    }
    return n;
  }
  function refreshCounts() {
    ['task', 'test'].forEach(function (tab) {
      var n = issueCount(tab), el = $('#cnt-' + tab);
      el.textContent = n;
      el.className = 'cnt' + (n ? '' : ' zero');
      el.title = n ? '확인 필요 ' + n + '건' : '문제 없음';
      $('#dot-' + tab).classList.toggle('show', n > 0);
    });
  }
  function refreshChecks() {
    document.querySelectorAll('[data-check]').forEach(function (el) {
      var kind = el.getAttribute('data-check'), r;
      if (kind === 'refs') {
        r = checkRefs(getPath(el.getAttribute('data-ref')), +el.getAttribute('data-idx'));
      } else {
        var extraRef = el.getAttribute('data-extra');
        r = check(kind, getPath(el.getAttribute('data-ref')), extraRef ? getPath(extraRef) : '');
      }
      el.className = 'badge ' + r[0];
      el.textContent = r[1];
    });
    document.querySelectorAll('[data-rt]').forEach(function (el) {
      var t = requestType(getPath(el.getAttribute('data-rt')));
      el.className = 'rt ' + t[0];
      el.textContent = t[1];
    });
    document.querySelectorAll('[data-qs]').forEach(function (el) {
      var it = getPath(el.getAttribute('data-qs'));
      if (it.method !== 'GET' && it.method !== 'DELETE') { el.textContent = ''; return; }
      var q = it.body.trim() ? toQuery(it.body) : '';
      el.textContent = q === null ? '→ JSON을 고치면 실제 요청 주소가 보입니다' : '→ 실제 요청: ' + it.method + ' ' + (it.api || '/') + q;
    });
    document.querySelectorAll('[data-files]').forEach(function (el) {
      var i = el.getAttribute('data-files');
      var files = fileFields(state.test.items[i].body);
      el.innerHTML = files.map(function (f) {
        return '<div class="file-row">' + ICON.clip + '<span class="k">' + esc(f.key) + '</span><span class="p" title="' + esc(f.path) + '">' + esc(f.path || '경로 없음') + '</span>' +
          '<button class="mini" data-act="file-change" data-i="' + i + '" data-key="' + esc(f.key) + '">파일 선택</button></div>';
      }).join('');
    });
    refreshCounts();
  }

  /* ---------- JSON 강조 ---------- */
  function hlRefs(s) {
    return s.replace(/\{\d+번 응답 ?[^}]*\}/g, function (r) {
      return '<span class="t-ref' + (/응답 ?(필드)?\}$/.test(r) ? ' todo' : '') + '">' + r + '</span>';
    });
  }
  function hlJson(text) {
    var re = /("(?:[^"\\\n]|\\.)*"?)(\s*:)?|(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)|\b(true|false|null)\b|([{}\[\]])|([,:])/g;
    var out = '', last = 0, m;
    while ((m = re.exec(text))) {
      out += esc(text.slice(last, m.index));
      if (m[1] !== undefined) {
        var s = hlRefs(esc(m[1])).replace(/\(multipart\)/g, '<span class="t-mp">(multipart)</span>');
        out += m[2] !== undefined ? '<span class="t-key">' + s + '</span><span class="t-pun">' + esc(m[2]) + '</span>' : '<span class="t-str">' + s + '</span>';
      } else if (m[3] !== undefined) {
        out += '<span class="t-num">' + m[3] + '</span>';
      } else if (m[4] !== undefined) {
        out += '<span class="t-bool">' + m[4] + '</span>';
      } else if (m[5] !== undefined) {
        out += '<span class="t-br">' + esc(m[5]) + '</span>';
      } else {
        out += '<span class="t-pun">' + m[6] + '</span>';
      }
      last = re.lastIndex;
      if (m[0] === '') re.lastIndex++;
    }
    return out + esc(text.slice(last));
  }
  function paintCode(ta) {
    var box = ta.closest('.code-box');
    var text = ta.value, errLine = jsonErrorLine(text);
    box.querySelector('.code-hl').innerHTML = hlJson(text) + '\n';
    var n = text.split('\n').length, g = '';
    for (var i = 1; i <= n; i++) g += '<span' + (i === errLine ? ' class="err"' : '') + '>' + i + '</span>';
    box.querySelector('.gutter').innerHTML = g;
  }

  /* ---------- 편집 편의 ---------- */
  function insertText(el, text) { el.focus(); document.execCommand('insertText', false, text); }
  function deleteRange(ta, from, to) { ta.setSelectionRange(from, to); document.execCommand('delete'); }
  function formatTa(ta) {
    if (!ta.value.trim()) return;
    var line = jsonErrorLine(ta.value);
    if (line) { toast('JSON 오류(' + line + '행)가 있어서 정렬할 수 없습니다'); return; }
    ta.focus();
    ta.select();
    document.execCommand('insertText', false, JSON.stringify(JSON.parse(ta.value), null, 2));
  }
  function selectField(el) {
    var p = el.selectionStart;
    el.setSelectionRange(p - FIELD.length - 1, p - 1);
  }
  /* from 앞쪽에서 아직 안 닫힌 여는 괄호를 찾아 그 줄의 들여쓰기를 돌려줌 (문자열 안 괄호는 건너뜀) */
  function openIndent(v, from) {
    var depth = 0, inStr = false;
    for (var i = from - 1; i >= 0; i--) {
      var c = v.charAt(i);
      if (c === '"' && v.charAt(i - 1) !== '\\') { inStr = !inStr; continue; }
      if (inStr) continue;
      if (c === '}' || c === ']') depth++;
      else if (c === '{' || c === '[') {
        if (depth) { depth--; continue; }
        var ls = v.lastIndexOf('\n', i - 1) + 1;
        return /^ */.exec(v.slice(ls))[0];
      }
    }
    return null;
  }
  /* 파일 경로 넣을 자리: "필드": "값" 의 값 안이면 값 범위, "필드": 바로 뒤면 따옴표째 넣을 자리 */
  function valueSlot(ta) {
    var v = ta.value, s = ta.selectionStart;
    var lineStart = v.lastIndexOf('\n', s - 1) + 1, before = v.slice(lineStart, s);
    var m = /"[^"]*"\s*:\s*"([^"]*)$/.exec(before);
    if (m) {
      var end = v.indexOf('"', s), nl = v.indexOf('\n', s);
      if (end !== -1 && (nl === -1 || end < nl)) return { from: s - m[1].length, to: end, quote: false };
    }
    if (/"[^"]*"\s*:\s*$/.test(before)) return { from: s, to: s, quote: true };
    return null;
  }
  function onCodeKey(e, ta) {
    if (e.isComposing) return;
    var v = ta.value, s = ta.selectionStart, en = ta.selectionEnd;
    var prev = v.charAt(s - 1), next = v.charAt(en);
    var lineStart = v.lastIndexOf('\n', s - 1) + 1;
    var indent = /^ */.exec(v.slice(lineStart))[0];
    if (e.key === 'Tab') {
      e.preventDefault();
      if (!e.shiftKey) { insertText(ta, '  '); return; }
      var rm = Math.min(2, indent.length);
      if (rm) { deleteRange(ta, lineStart, lineStart + rm); var p = Math.max(lineStart, s - rm); ta.setSelectionRange(p, p); }
      return;
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      if ((prev === '{' && next === '}') || (prev === '[' && next === ']')) {
        insertText(ta, '\n' + indent + '  \n' + indent);
        var c = s + 1 + indent.length + 2;
        ta.setSelectionRange(c, c);
      } else if (prev === '{' || prev === '[') {
        insertText(ta, '\n' + indent + '  ');
      } else {
        insertText(ta, '\n' + indent);
      }
      return;
    }
    if (s === en && (e.key === '}' || e.key === ']' || e.key === '"') && next === e.key) {
      e.preventDefault(); ta.setSelectionRange(s + 1, s + 1); return;
    }
    /* 빈 줄에서 닫는 괄호를 치면 짝이 되는 여는 괄호 줄의 들여쓰기에 맞춤 */
    if (s === en && (e.key === '}' || e.key === ']') && /^ *$/.test(v.slice(lineStart, s))) {
      var want = openIndent(v, lineStart);
      if (want !== null && want !== v.slice(lineStart, s)) {
        e.preventDefault();
        ta.setSelectionRange(lineStart, s);
        insertText(ta, want + e.key);
        return;
      }
    }
    if (PAIRS[e.key]) {
      e.preventDefault();
      var sel = v.slice(s, en);
      insertText(ta, e.key + sel + PAIRS[e.key]);
      ta.setSelectionRange(s + 1, s + 1 + sel.length);
      return;
    }
    if (e.key === 'Backspace' && s === en && s > 0) {
      if (PAIRS[prev] && PAIRS[prev] === next) { e.preventDefault(); deleteRange(ta, s - 1, s + 1); return; }
      var before = v.slice(lineStart, s);
      if (before.length >= 2 && /^ +$/.test(before)) { e.preventDefault(); deleteRange(ta, s - 2, s); }
    }
  }
  function onDetailKey(e, ta) {
    if (e.isComposing || e.key !== 'Enter' || e.shiftKey) return;
    var v = ta.value, s = ta.selectionStart;
    var lineStart = v.lastIndexOf('\n', s - 1) + 1;
    var line = v.slice(lineStart, s);
    var bullet = /^\s*- /.exec(line);
    if (!bullet) return;
    e.preventDefault();
    if (line === bullet[0]) deleteRange(ta, lineStart, s);
    else insertText(ta, '\n' + bullet[0]);
  }

  /* ---------- 폼 조각 ---------- */
  function picker(path, value, mode) {
    var v = (value || '').trim();
    return '<button class="picker' + (v ? '' : ' empty') + '" data-act="pick" data-path="' + path + '" data-mode="' + mode + '">' +
      (v ? '<span class="grp">' + esc(groupOf(v)) + '</span>' : '') +
      '<span class="picker-val">' + esc(v || '프로젝트 선택') + '</span>' + ICON.chev + '</button>';
  }
  function badge(kind, ref, extra) {
    return '<span data-check="' + kind + '" data-ref="' + ref + '"' + (extra ? ' data-extra="' + extra + '"' : '') + '></span>';
  }
  function tools(list, i, n, uid) {
    var folded = !!ui.collapsed[uid];
    var a = ' data-list="' + list + '" data-i="' + i + '" data-uid="' + uid + '"';
    return '<div class="tools">' +
      '<button class="icon-btn" data-act="fold-item"' + a + ' title="' + (folded ? '펼치기' : '접기') + '">' + (folded ? ICON.expand : ICON.collapse) + '</button>' +
      '<button class="icon-btn" data-act="up"' + a + ' title="위로"' + (i === 0 ? ' disabled' : '') + '>' + ICON.up + '</button>' +
      '<button class="icon-btn" data-act="down"' + a + ' title="아래로"' + (i === n - 1 ? ' disabled' : '') + '>' + ICON.down + '</button>' +
      '<button class="icon-btn" data-act="dup"' + a + ' title="복제">' + ICON.copy + '</button>' +
      '<button class="icon-btn danger" data-act="del"' + a + ' title="삭제">' + ICON.x + '</button>' +
      '</div>';
  }
  function itemOpen(it, i, ordered, style) {
    var cls = 'item' + (ui.collapsed[it.uid] ? ' collapsed' : '') + (ui.enter === it.uid ? ' enter' : '');
    return '<div class="' + cls + '" data-uid="' + it.uid + '"' + (style ? ' style="' + style + '"' : '') + '>' +
      '<div class="num' + (ordered ? '' : ' free') + '">' + (ordered ? i + 1 : '•') + '</div>';
  }
  function delBtn(list, i) { return '<button class="icon-btn danger" data-act="del" data-list="' + list + '" data-i="' + i + '" title="삭제">' + ICON.x + '</button>'; }
  function addBtn(list, label) { return '<button class="add" data-act="add" data-list="' + list + '">' + ICON.plus + label + '</button>'; }
  function orderSeg(tab, ordered) {
    return '<div class="seg"><button data-act="order" data-tab="' + tab + '" data-v="1" class="' + (ordered ? 'on' : '') + '">순번 있음</button>' +
      '<button data-act="order" data-tab="' + tab + '" data-v="0" class="' + (ordered ? '' : 'on') + '">순번 없음</button></div>';
  }
  function card(id, title, count, desc, guide, body, right) {
    var open = !!ui.guides[id];
    return '<section class="card"><div class="card-head">' +
      '<div><h2 class="card-title">' + title + (count != null ? '<span class="count">' + count + '</span>' : '') + '</h2><p class="card-desc">' + desc + '</p></div>' +
      '<div class="card-tools">' + (right || '') + '<button class="ghost' + (open ? ' on' : '') + '" data-act="guide" data-id="' + id + '">' + ICON.book + '안내</button></div>' +
      '</div><div class="guide' + (open ? ' show' : '') + '">' + esc(guide) + '</div>' + body + '</section>';
  }
  function emptyHint(tab) {
    return chosen(tab).length ? '' : '<div class="empty-hint">↑ 위에서 ' + (tab === 'task' ? '대상 프로젝트' : '프로젝트와 호스트') + '를 먼저 고르면, 여기서 그중에 골라 쓸 수 있습니다.</div>';
  }

  function renderTask() {
    var s = state.task;
    var rows = s.projects.map(function (p, i) {
      var base = 'task.projects.' + i;
      return '<div class="row">' + picker(base + '.project', p.project, 'workspace') +
        '<input class="input mono" data-path="' + base + '.branch" value="' + esc(p.branch) + '" placeholder="issue-cherry-1234" spellcheck="false" autocomplete="off">' +
        '<div style="display:flex;gap:6px">' + badge('inws', base + '.project') + badge('branch', base + '.branch', base + '.project') + '</div>' +
        delBtn('task.projects', i) + '</div>';
    }).join('');
    var items = s.items.map(function (it, i) {
      var base = 'task.items.' + i, head = itemOpen(it, i, s.ordered, '');
      if (ui.collapsed[it.uid]) {
        var lines = it.detail.split('\n').filter(function (d) { return d.trim(); }).length;
        return head + '<div class="item-body"><div class="item-head">' +
          '<button class="sum" data-act="fold-item" data-uid="' + it.uid + '"><span class="sum-proj">[' + esc(it.project || '프로젝트') + ']</span><span class="sum-title">' + esc(it.title || '개요 없음') + '</span><span class="sum-proj">상세 ' + lines + '줄</span></button>' +
          badge('intarget', base + '.project') + tools('task.items', i, s.items.length, it.uid) + '</div></div></div>';
      }
      return head + '<div class="item-body"><div class="item-head">' +
          '<div class="w-proj">' + picker(base + '.project', it.project, 'targets:task') + '</div>' +
          '<input class="input grow" data-path="' + base + '.title" value="' + esc(it.title) + '" placeholder="개요 (예: 결제 환불기능 추가)">' +
          badge('intarget', base + '.project') + tools('task.items', i, s.items.length, it.uid) +
        '</div>' +
        '<textarea class="input detail-ta" data-path="' + base + '.detail" placeholder="- 무엇을 어떻게 할지 (Enter 치면 - 가 자동으로 이어집니다)">' + esc(it.detail) + '</textarea>' +
        '</div></div>';
    }).join('');
    return card('t1', '대상 프로젝트 및 브랜치', s.projects.length, '워크스페이스 프로젝트 중에서 고르기 · 없는 프로젝트나 빠진 브랜치가 있으면 전체 작업 불가', guide('task', 0),
        rows + addBtn('task.projects', '프로젝트 추가')) +
      card('t2', '작업 내용', s.items.length, s.ordered ? '연관 작업 · 완료 후 다음 진행 (1요청 1작업)' : '독립 작업 · 한 번에 진행 (1요청 N작업)', guide('task', 1),
        emptyHint('task') + items + addBtn('task.items', '작업 추가'), orderSeg('task', s.ordered));
  }

  function methodChips(i, current) {
    return '<div class="methods">' + METHODS.map(function (m) {
      return '<button class="m' + (m === current ? ' on' : '') + '" style="--mc:var(--' + m.toLowerCase() + ')" data-act="method" data-i="' + i + '" data-v="' + m + '">' + m + '</button>';
    }).join('') + '</div>';
  }
  function renderTest() {
    var s = state.test;
    var hosts = s.hosts.map(function (h, i) {
      var base = 'test.hosts.' + i;
      return '<div class="row">' + picker(base + '.project', h.project, 'workspace') +
        '<input class="input mono" data-path="' + base + '.host" value="' + esc(h.host) + '" placeholder="http://localhost:8080" spellcheck="false" autocomplete="off">' +
        '<div style="display:flex;gap:6px">' + badge('inws', base + '.project') + badge('host', base + '.host', base + '.project') + '</div>' +
        delBtn('test.hosts', i) + '</div>';
    }).join('');
    var token = '<div class="row" style="margin-top:14px"><span class="label">Authorization</span>' +
      '<div class="token"><span class="bearer">Bearer</span><input type="' + (ui.showToken ? 'text' : 'password') + '" data-path="test.token" value="' + esc(s.token) + '" placeholder="개발·운영일 때만 입력" spellcheck="false" autocomplete="off"></div>' +
      '<span></span><button class="icon-btn" data-act="eye" title="' + (ui.showToken ? '가리기' : '보기') + '">' + ICON.eye + '</button></div>';
    var items = s.items.map(function (it, i) {
      var base = 'test.items.' + i, quiet = it.method === 'GET' || it.method === 'DELETE';
      var head = itemOpen(it, i, s.ordered, '--c:var(--' + it.method.toLowerCase() + ')');
      var checks = badge('inhost', base + '.project') + '<span data-check="refs" data-ref="' + base + '" data-idx="' + i + '"></span>';
      if (ui.collapsed[it.uid]) {
        return head + '<div class="item-body"><div class="item-head">' +
          '<button class="sum" data-act="fold-item" data-uid="' + it.uid + '"><span class="api-m">' + it.method + '</span><span class="sum-api">' + esc(it.api || '/') + '</span><span class="sum-proj">[' + esc(it.project || '프로젝트') + ']</span></button>' +
          checks + badge('json', base + '.body', base + '.method') + tools('test.items', i, s.items.length, it.uid) + '</div></div></div>';
      }
      var refs = '';
      if (s.ordered && i > 0) {
        for (var n = 1; n <= i; n++) refs += '<button class="chip" data-act="ref" data-i="' + i + '" data-n="' + n + '" title="커서 위치에 넣고 필드 부분을 선택 (커서가 없으면 API 끝에)">{' + n + '번 응답 필드}</button>';
        refs = '<div class="refs"><span class="refs-label">이전 응답 참조</span>' + refs + '</div>';
      }
      return head + '<div class="item-body"><div class="item-head">' +
          '<div class="w-proj">' + picker(base + '.project', it.project, 'targets:test') + '</div>' +
          methodChips(i, it.method) + checks + tools('test.items', i, s.items.length, it.uid) +
        '</div>' +
        '<div class="api"><span class="api-m">' + it.method + '</span>' +
          '<input data-path="' + base + '.api" value="' + esc(it.api) + '" placeholder="/v1/..." spellcheck="false" autocomplete="off">' + badge('api', base + '.api') + '</div>' +
        refs +
        '<div class="code-ed">' +
          '<div class="code-top"><span class="code-label">' + (quiet ? 'QUERY · JSON' : 'BODY · JSON') + '</span><span data-rt="' + base + '"></span>' +
            badge('json', base + '.body', base + '.method') +
            (quiet ? '' : '<button class="mini" data-act="file-add" data-i="' + i + '" title="커서가 있는 필드 값에 파일 경로 넣기 (필드명은 직접 입력)">' + ICON.clip + '파일 선택</button>') +
            '<button class="mini" data-act="format" data-path="' + base + '.body" title="JSON 정렬 (Ctrl+Alt+L)">' + ICON.wand + '정렬</button>' +
          '</div>' +
          '<div class="code-box"><div class="gutter" aria-hidden="true"></div><div class="code-area"><pre class="code-hl" aria-hidden="true"></pre>' +
            '<textarea class="code-ta" data-path="' + base + '.body" spellcheck="false" placeholder="' + (quiet ? '{ "page": 1 }  · 짱구가 쿼리스트링으로 바꿔 보냅니다' : '{ "key": "value" }') + '">' + esc(it.body) + '</textarea>' +
          '</div></div>' +
          (quiet ? '' : '<div class="files" data-files="' + i + '"></div>') +
          '<div class="code-help"><span class="qs" data-qs="' + base + '"></span><span class="keys">괄호·따옴표 자동 짝 · Enter 자동 들여쓰기 · Tab 2칸</span></div>' +
        '</div>' +
      '</div></div>';
    }).join('');
    return card('s1', '대상 프로젝트 및 호스트', s.hosts.length, '워크스페이스 프로젝트 중에서 고르기 · 개발·운영 서버면 토큰도 입력 · 없는 프로젝트나 빠진 호스트가 있으면 전체 테스트 불가', guide('test', 0),
        hosts + addBtn('test.hosts', '호스트 추가') + token) +
      card('s2', '테스트 내용', s.items.length, s.ordered ? '연관 테스트 · 완료 후 다음 진행 (1요청 1작업) · JSON 아닌 데이터가 있으면 전체 테스트 불가' : '독립 테스트 · 한 번에 진행 (1요청 N작업) · JSON 아닌 데이터가 있으면 전체 테스트 불가', guide('test', 1),
        emptyHint('test') + items + addBtn('test.items', '테스트 추가'), orderSeg('test', s.ordered));
  }

  function autosize(el) { el.style.height = 'auto'; el.style.height = el.scrollHeight + 2 + 'px'; }
  function renderForm() {
    var sy = sync[ui.tab];
    if (!sy.ok) {
      form.innerHTML = '<div class="ro-note"><b>' + FILES[ui.tab] + '은(는) 화면에서 편집하지 않습니다.</b><br>' + esc(sy.error) +
        '<br>md가 망가지지 않도록 이 탭은 읽기만 합니다. md를 템플릿 형식으로 고치면 바로 다시 편집할 수 있습니다.</div>';
      refreshCounts();
      return;
    }
    form.innerHTML = ui.tab === 'task' ? renderTask() : renderTest();
    form.querySelectorAll('textarea.detail-ta').forEach(autosize);
    form.querySelectorAll('textarea.code-ta').forEach(paintCode);
    refreshChecks();
    ui.enter = null;
  }

  /* ---------- 프로젝트 선택 목록 ---------- */
  function openPicker(btn) {
    pick.path = btn.getAttribute('data-path');
    pick.mode = btn.getAttribute('data-mode');
    pick.button = btn;
    pick.q = '';
    document.querySelectorAll('.picker.open').forEach(function (b) { b.classList.remove('open'); });
    btn.classList.add('open');
    var r = btn.getBoundingClientRect(), pop = $('#pop');
    pop.style.left = Math.min(r.left, window.innerWidth - 316) + 'px';
    pop.style.top = (r.bottom + 6 + 360 > window.innerHeight ? Math.max(8, r.top - 366) : r.bottom + 6) + 'px';
    pop.style.width = Math.max(r.width, 300) + 'px';
    $('#pop-search').value = '';
    $('#pop-search').style.display = pick.mode === 'workspace' ? '' : 'none';
    renderPickList();
    pop.classList.add('show');
    if (pick.mode === 'workspace') $('#pop-search').focus();
  }
  function closePicker() {
    $('#pop').classList.remove('show');
    if (pick.button) pick.button.classList.remove('open');
    pick.path = null;
    pick.button = null;
  }
  function renderPickList() {
    var current = (getPath(pick.path) || '').trim(), html = '';
    if (pick.mode === 'workspace') {
      var tab = pick.path.indexOf('task.') === 0 ? 'task' : 'test';
      var taken = chosen(tab), groups = {};
      WORKSPACE.filter(function (n) { return n.indexOf(pick.q) >= 0; }).forEach(function (n) { (groups[groupOf(n)] = groups[groupOf(n)] || []).push(n); });
      Object.keys(groups).forEach(function (g) {
        html += '<div class="pop-grp">' + esc(g) + '</div>' + groups[g].map(function (n) {
          var used = taken.indexOf(n) >= 0 && n !== current;
          return '<button class="opt' + (n === current ? ' cur' : '') + '" data-act="pick-opt" data-v="' + esc(n) + '"' + (used ? ' disabled' : '') + '>' + esc(n) + (used ? '<small>선택됨</small>' : '') + '</button>';
        }).join('');
      });
      if (!html) html = '<div class="pop-empty">일치하는 프로젝트가 없습니다</div>';
    } else {
      var list = chosen(pick.mode.split(':')[1]);
      html = '<div class="pop-grp">위에서 고른 프로젝트</div>' + (list.length ? list.map(function (n) {
        return '<button class="opt' + (n === current ? ' cur' : '') + '" data-act="pick-opt" data-v="' + esc(n) + '">' + esc(n) + '</button>';
      }).join('') : '<div class="pop-empty">위에서 먼저 프로젝트를 고르세요</div>');
    }
    $('#pop-list').innerHTML = html;
  }

  /* ---------- md 생성 ---------- */
  function pushAll(L, text) { text.split('\n').forEach(function (x) { L.push(x); }); }
  /* 템플릿 안내(<!-- -->)는 md에 있던 그대로 다시 쓴다 (없을 때만 기본 안내) */
  function guide(tab, n) {
    var g = sync[tab].guides[n];
    return g != null ? g : GUIDE[tab + (n + 1)];
  }
  /* 상세의 앞뒤 빈 줄만 빼고, 중간 빈 줄은 그대로 둔다 */
  function blockLines(text) {
    var t = text.replace(/\s+$/, '').replace(/^(\s*\n)+/, '');
    return t ? t.split('\n') : [];
  }
  function taskMd(s, map) {
    var L = ['# TASK', '', '## 대상 프로젝트 및 브랜치', '<!--'];
    pushAll(L, guide('task', 0));
    L.push('-->');
    var top = L.length;
    s.projects.forEach(function (p) { if (p.project || p.branch) L.push(p.project + ': ' + p.branch); });
    if (L.length === top) L.push('');   /* 비어 있으면 템플릿처럼 빈 줄 하나 */
    L.push('', '## 작업 내용', '<!--');
    pushAll(L, guide('task', 1));
    L.push('-->');
    var n = 0;
    s.items.forEach(function (it) {
      if (!it.project && !it.title && !it.detail.trim()) return;
      n++;
      if (!s.ordered && n > 1) L.push('');
      var start = L.length + 1;
      L.push((s.ordered ? n + '. ' : '') + '[' + it.project + '] ' + it.title);
      blockLines(it.detail).forEach(function (d) { L.push(d); });
      if (map) map[it.uid] = [start, L.length];
    });
    return L.join('\n');
  }
  function testMd(s, map) {
    var L = ['# TEST', '', '## 대상 프로젝트 및 호스트', '<!--'];
    pushAll(L, guide('test', 0));
    L.push('-->');
    var top = L.length;
    if (s.token.trim()) L.push('Authorization: Bearer ' + s.token.trim());
    s.hosts.forEach(function (h) { if (h.project || h.host) L.push(h.project + ': ' + h.host); });
    if (L.length === top) L.push('');   /* 비어 있으면 템플릿처럼 빈 줄 하나 */
    L.push('', '## 테스트 내용', '<!--');
    pushAll(L, guide('test', 1));
    L.push('-->');
    var n = 0;
    s.items.forEach(function (it) {
      if (!it.project && !it.api && !it.body.trim()) return;
      n++;
      if (!s.ordered && n > 1) L.push('');
      var start = L.length + 1;
      L.push((s.ordered ? n + '. ' : '') + '[' + it.project + '] ' + it.method + ' ' + it.api);
      blockLines(it.body).forEach(function (b) { L.push(b); });
      if (map) map[it.uid] = [start, L.length];
    });
    return L.join('\n');
  }
  function currentMd(tab, map) { return tab === 'task' ? taskMd(state.task, map) : testMd(state.test, map); }

  /* ---------- md 읽기 (템플릿 형식 → 화면 상태) ----------
     형식이 템플릿과 다르면 ok: false 로 돌려주고, 화면은 그 탭을 편집하지 않는다 (md를 망가뜨리지 않게) */
  var HEADS = {
    task: ['# TASK', '## 대상 프로젝트 및 브랜치', '## 작업 내용'],
    test: ['# TEST', '## 대상 프로젝트 및 호스트', '## 테스트 내용']
  };
  function splitSections(tab, text) {
    var lines = text.split('\n'), heads = HEADS[tab];
    if ((lines[0] || '').trim() !== heads[0]) return { error: '첫 줄이 ' + heads[0] + ' 가 아닙니다' };
    var at = [heads[1], heads[2]].map(function (h) { return lines.findIndex(function (l) { return l.trim() === h; }); });
    if (at[0] < 0 || at[1] < 0 || at[1] < at[0]) return { error: '"' + heads[1] + '" / "' + heads[2] + '" 제목을 찾을 수 없습니다' };
    if (lines.slice(1, at[0]).some(function (l) { return l.trim(); })) return { error: heads[0] + ' 아래에 알 수 없는 내용이 있습니다' };
    var out = { guides: [], bodies: [] };
    [[at[0] + 1, at[1]], [at[1] + 1, lines.length]].forEach(function (r) {
      var sec = lines.slice(r[0], r[1]), i = 0;
      while (i < sec.length && !sec[i].trim()) i++;
      var g = null;
      if (i < sec.length && sec[i].trim() === '<!--') {
        var end = sec.indexOf('-->', i + 1);
        if (end < 0) end = sec.findIndex(function (l, k) { return k > i && l.trim() === '-->'; });
        if (end < 0) { out.error = '템플릿 안내(<!-- -->)가 닫히지 않았습니다'; return; }
        g = sec.slice(i + 1, end).join('\n');
        i = end + 1;
      }
      out.guides.push(g);
      out.bodies.push(sec.slice(i));
    });
    return out;
  }
  function trimBlank(lines) {
    var a = 0, b = lines.length;
    while (a < b && !lines[a].trim()) a++;
    while (b > a && !lines[b - 1].trim()) b--;
    return lines.slice(a, b);
  }
  var ITEM_HEAD = /^(\d+\.\s+)?\[([^\]]*)\]\s?(.*)$/;
  function parseItems(lines, onHead) {
    var items = [], ordered = null, cur = null, error = null;
    trimBlank(lines).forEach(function (l) {
      if (error) return;
      var m = ITEM_HEAD.exec(l);
      if (m) {
        if (ordered === null) ordered = !!m[1];
        cur = onHead(m[2].trim(), m[3]);
        if (!cur) { error = '항목 줄을 읽을 수 없습니다: ' + l; return; }
        cur.uid = nid();
        cur.lines = [];
        items.push(cur);
      } else if (cur) {
        cur.lines.push(l);
      } else {
        error = '첫 항목 앞에 알 수 없는 내용이 있습니다: ' + l;
      }
    });
    return { items: items, ordered: ordered === null ? true : ordered, error: error };
  }
  function parseMd(tab, text) {
    var sec = splitSections(tab, text);
    if (sec.error) return { ok: false, error: sec.error };
    var s = emptyTab(tab), top = trimBlank(sec.bodies[0]), bad = null;
    if (tab === 'task') {
      var projects = [];
      top.forEach(function (l) {
        var m = /^([^:\s][^:]*):\s?(.*)$/.exec(l);
        if (m) projects.push({ project: m[1].trim(), branch: m[2].trim() });
        else if (l.trim()) bad = bad || l;
      });
      if (bad) return { ok: false, error: '대상 프로젝트 줄을 읽을 수 없습니다: ' + bad };
      var r = parseItems(sec.bodies[1], function (project, rest) { return { project: project, title: rest.trim(), detail: '' }; });
      if (r.error) return { ok: false, error: r.error };
      r.items.forEach(function (it) { it.detail = trimBlank(it.lines).join('\n'); delete it.lines; });
      if (projects.length) s.projects = projects;
      if (r.items.length) s.items = r.items;
      s.ordered = r.ordered;
    } else {
      var hosts = [];
      top.forEach(function (l) {
        var t = /^Authorization:\s*Bearer\s*(.*)$/.exec(l), m = /^([^:\s][^:]*):\s?(.*)$/.exec(l);
        if (t) s.token = t[1].trim();
        else if (m) hosts.push({ project: m[1].trim(), host: m[2].trim() });
        else if (l.trim()) bad = bad || l;
      });
      if (bad) return { ok: false, error: '대상 프로젝트·호스트 줄을 읽을 수 없습니다: ' + bad };
      var q = parseItems(sec.bodies[1], function (project, rest) {
        var m = /^([A-Za-z]+)\s+(\S*)\s*(.*)$/.exec(rest.trim());
        if (!m) return null;
        return { project: project, method: m[1].toUpperCase(), api: m[2], body: '', inline: m[3] };
      });
      if (q.error) return { ok: false, error: q.error };
      q.items.forEach(function (it) {
        it.body = trimBlank((it.inline ? [it.inline] : []).concat(it.lines)).join('\n');
        delete it.lines;
        delete it.inline;
      });
      if (hosts.length) s.hosts = hosts;
      if (q.items.length) s.items = q.items;
      s.ordered = q.ordered;
    }
    return { ok: true, state: s, guides: sec.guides };
  }

  function hl(line) {
    if (/^#/.test(line)) return '<span class="h">' + esc(line) + '</span>';
    if (/^Authorization: Bearer /.test(line)) {
      var tok = line.slice('Authorization: Bearer '.length);
      return '<span class="a">Authorization: Bearer ' + esc(ui.showToken ? tok : new Array(Math.min(tok.length, 16) + 1).join('●')) + '</span>';
    }
    var m = /^(\d+\. )?\[([^\]]*)\](.*)$/.exec(line);
    if (m) {
      var rest = hlRefs(esc(m[3]).replace(/^(\s)(GET|POST|PUT|PATCH|DELETE)\b/, function (_, sp, k) {
        return sp + '<span style="color:var(--' + k.toLowerCase() + ');font-weight:700">' + k + '</span>';
      }));
      return (m[1] ? '<span class="n">' + m[1] + '</span>' : '') + '<span class="p">[' + esc(m[2]) + ']</span>' + rest;
    }
    if (/^- /.test(line)) return '<span class="d">' + esc(line) + '</span>';
    if (/^[\s{}\[\]"]/.test(line)) return hlJson(line);
    var kv = /^([\w.-]+): (.*)$/.exec(line);
    if (kv) return '<span class="p">' + esc(kv[1]) + '</span>: ' + esc(kv[2]);
    return esc(line);
  }
  function pline(no, html, cls) {
    return '<div class="pl' + (cls ? ' ' + cls : '') + '"><span class="no">' + no + '</span><span class="tx">' + (html || ' ') + '</span></div>';
  }
  function renderPreview() {
    var map = {}, lines = (sync[ui.tab].ok ? currentMd(ui.tab, map) : sync[ui.tab].raw).split('\n'), out = [], i = 0;
    var hot = ui.focusUid ? map[ui.focusUid] : null;
    while (i < lines.length) {
      if (lines[i].trim() === '<!--') {
        var j = i;
        while (j < lines.length && lines[j].trim() !== '-->') j++;
        if (ui.foldGuide) out.push(pline(i + 1, '<span class="c fold" data-act="fold">&lt;!-- 템플릿 안내 ' + (j - i - 1) + '줄 · 그대로 유지 --&gt;</span>'));
        else for (var k = i; k <= j && k < lines.length; k++) out.push(pline(k + 1, '<span class="c">' + esc(lines[k]) + '</span>'));
        i = j + 1;
        continue;
      }
      out.push(pline(i + 1, hl(lines[i]), hot && i + 1 >= hot[0] && i + 1 <= hot[1] ? 'hot' : ''));
      i++;
    }
    var body = $('#preview');
    body.innerHTML = out.join('');
    $('#pv-file').textContent = FILES[ui.tab];
    $('#pv-lines').textContent = lines.length + '줄';
    $('#pv-fold').textContent = ui.foldGuide ? '안내 펼치기' : '안내 접기';
    if (ui.scrollHot) {
      ui.scrollHot = false;
      var first = body.querySelector('.pl.hot');
      if (first) body.scrollTop = Math.max(0, first.offsetTop - body.clientHeight / 3);
    }
  }

  /* ---------- 서버 ---------- */
  function api(path, body) {
    var url = path + '?t=' + encodeURIComponent(TOKEN);
    var opt = body === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
    return fetch(url, opt).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) { d.status = r.status; return d; });
    });
  }

  /* ---------- 상태 ---------- */
  var saveTimer = null;
  function setSynced() { $('#st-time').textContent = clock(); }
  function setSaveText(text, busy) {
    $('#save').classList.toggle('busy', !!busy);
    $('#save-text').textContent = text;
  }
  /* md 내용으로 화면 상태를 다시 만든다 (형식이 다르면 그 탭은 읽기 전용) */
  function loadTab(tab, text, version) {
    var sy = sync[tab], r = parseMd(tab, text);
    sy.raw = text;
    sy.base = version;
    sy.saved = sy.rev;
    sy.ok = r.ok;
    sy.error = r.error || '';
    if (r.ok) { state[tab] = r.state; sy.guides = r.guides; }
  }
  function dirty(tab) { return sync[tab].rev !== sync[tab].saved; }
  /* 화면이 바뀔 때마다 0.5초 뒤 저장 (충돌 팝업이 떠 있는 동안은 멈춤) */
  function saving() {
    var tab = ui.tab, sy = sync[tab];
    sy.rev++;
    sy.editedAt = new Date();
    clearTimeout(saveTimer);
    if (ui.conflict) { setSaveText('자동 저장 멈춤 · 선택 대기'); return; }
    setSaveText('저장 중…', true);
    saveTimer = setTimeout(function () { save(tab, false); }, 500);
  }
  /* 저장은 탭마다 한 번에 하나씩 (앞 저장이 끝나야 새 버전으로 비교할 수 있음) */
  function save(tab, force) {
    var sy = sync[tab];
    if (!sy.ok || (ui.conflict && !force)) return;
    if (sy.inflight) { sy.again = true; return; }
    var rev = sy.rev, text = currentMd(tab);
    sy.inflight = true;
    sy.pending = text;
    api('/api/save', { tab: tab, text: text, base: sy.base, force: !!force }).then(function (d) {
      sy.inflight = false;
      if (d.status === 200) {
        sy.base = d.version;
        sy.raw = text;
        sy.saved = rev;
        if (sy.again || dirty(tab)) { sy.again = false; save(tab, false); return; }
        setSaveText('저장됨 · ' + clock());
        setSynced();
      } else if (d.status === 409) {
        sy.again = false;
        openConflict(tab, d.text, d.version);
      } else {
        setSaveText('저장 실패');
        toast(FILES[tab] + ' 저장 실패: ' + (d.error || d.status));
      }
    }, function () {
      sy.inflight = false;
      setSaveText('저장 실패 · 서버 연결 없음');
    });
  }
  /* md가 밖에서(짱구가) 바뀌었을 때: 저장 안 된 입력이 없으면 바로 반영, 있으면 충돌 팝업 */
  function onRemote(tab, text, version) {
    var sy = sync[tab];
    if (version === sy.base) return;
    if (sy.ok && text === currentMd(tab)) {
      if (!sy.inflight) { sy.base = version; sy.raw = text; sy.saved = sy.rev; }
      return;
    }
    if (sy.inflight && text === sy.pending) return;
    if ((ui.conflict && ui.conflict.tab === tab) || (sy.ok && dirty(tab)) || sy.inflight) { openConflict(tab, text, version); return; }
    loadTab(tab, text, version);
    if (tab === ui.tab) renderAll(); else refreshCounts();
    setSynced();
    toast(FILES[tab] + ' 최신 내용으로 바뀌었습니다');
  }
  function toast(msg, actionLabel, action) {
    var el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = '<span class="dot"></span><span>' + esc(msg) + '</span>' + (actionLabel ? '<button>' + esc(actionLabel) + '</button>' : '');
    if (actionLabel) el.querySelector('button').addEventListener('click', function () { action(); el.remove(); });
    $('#toasts').appendChild(el);
    setTimeout(function () { el.remove(); }, actionLabel ? 8000 : 3500);
  }
  function changed() { renderForm(); renderPreview(); saving(); }
  function renderAll() {
    document.querySelectorAll('.nav-item').forEach(function (t) { t.classList.toggle('on', t.getAttribute('data-v') === ui.tab); });
    $('#st-file').textContent = FILES[ui.tab];
    $('#crumb-dir').textContent = ui.tab;
    $('#crumb-file').textContent = FILES[ui.tab];
    $('#page-title').textContent = TITLES[ui.tab];
    renderForm();
    renderPreview();
  }

  /* ---------- 목록 ---------- */
  function blank(list, prev) {
    var project = prev && prev.project ? prev.project : '';
    switch (list) {
      case 'task.projects': return { project: '', branch: '' };
      case 'task.items': return { uid: nid(), project: project, title: '', detail: '' };
      case 'test.hosts': return { project: '', host: '' };
      default: return { uid: nid(), project: project, method: 'GET', api: '', body: '' };
    }
  }
  var FIRST_FIELD = { 'task.items': 'title', 'test.items': 'api' };

  /* 충돌: 화면(저장 안 된 입력)과 바뀐 md 중 하나를 골라야 닫힘 */
  function openConflict(tab, text, version) {
    clearTimeout(saveTimer);
    ui.conflict = { tab: tab, text: text, version: version };
    if (ui.tab !== tab) { ui.tab = tab; renderAll(); }
    openModal();
  }
  /* 처음엔 작게, 비교하기를 누를 때만 넓어짐 */
  var animTimer = null;
  function openModal() {
    var c = ui.conflict, file = FILES[c.tab], sy = sync[c.tab];
    $('#conflict-box').classList.remove('large', 'anim');
    $('#modal-heading').textContent = '작성 중에 ' + file + '이(가) 바뀌었습니다';
    $('#modal-desc').textContent = '아직 저장되지 않은 입력이 있는 상태에서 ' + file + '이(가) 밖에서(짱구 등) 수정됐습니다. 어떤 내용을 남길까요?';
    $('#stamp-mine').textContent = '화면 입력 ' + (sy.editedAt ? clock(sy.editedAt) : '-');
    $('#stamp-theirs').textContent = 'md 변경 ' + clock() + ' · 최신';
    var strip = function (md) { return md.replace(/<!--[\s\S]*?-->/g, '<!-- 템플릿 안내 -->'); };
    var mine = strip(currentMd(c.tab)).split('\n'), theirs = strip(c.text).split('\n');
    /* 줄마다 블록 하나 (줄바꿈 문자를 섞으면 표시된 줄 뒤에 빈 줄이 생김) */
    var mark = function (lines, other, cls) {
      return lines.map(function (l) { return '<span class="' + (other.indexOf(l) === -1 ? cls : 'ln') + '">' + (esc(l) || ' ') + '</span>'; }).join('');
    };
    $('#diff-mine').innerHTML = mark(mine, theirs, 'mine');
    $('#diff-theirs').innerHTML = mark(theirs, mine, 'theirs');
    $('#diff').classList.remove('show');
    $('#modal').classList.add('show');
    setSaveText('자동 저장 멈춤 · 선택 대기');
  }
  /* 충돌 팝업은 '내 작성 유지' / 'md 불러오기'로만 닫힘 (닫기 버튼·바깥 클릭·Esc 없음) */
  function closeModal() { ui.conflict = null; $('#modal').classList.remove('show'); }

  /* 윈도우 파일 선택창 (서버가 띄우고 고른 경로만 돌려줌, 파일 내용은 읽지 않음) */
  function pickFile() {
    api('/api/pick-file', {}).then(function (d) {
      if (d.path) applyFile(d.path);
      else fileTarget = null;
    }, function () {
      fileTarget = null;
      toast('파일 선택창을 열 수 없습니다');
    });
  }
  function applyFile(path) {
    var t = fileTarget;
    fileTarget = null;
    if (!t) return;
    if (t.key) {
      var it = state.test.items[t.i];
      var re = new RegExp('("' + t.key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '"\\s*:\\s*")[^"]*?(\\s*\\(multipart\\)")');
      it.body = it.body.replace(re, '$1' + path + '$2');
      changed();
    } else if (t.ta) {
      t.ta.focus();
      t.ta.setSelectionRange(t.from, t.to);
      insertText(t.ta, t.quote ? '"' + path + ' (multipart)"' : path + ' (multipart)');
    }
  }

  /* ---------- 이벤트 ---------- */
  form.addEventListener('input', function (e) {
    var el = e.target, path = el.getAttribute('data-path');
    if (!path) return;
    setPath(path, el.value);
    if (el.classList.contains('detail-ta')) autosize(el);
    if (el.classList.contains('code-ta')) paintCode(el);
    refreshChecks();
    renderPreview();
    saving();
  });
  form.addEventListener('keydown', function (e) {
    var el = e.target;
    if (el.classList.contains('code-ta') && e.ctrlKey && e.altKey && e.code === 'KeyL') { e.preventDefault(); formatTa(el); return; }
    if (el.classList.contains('code-ta')) onCodeKey(e, el);
    else if (el.classList.contains('detail-ta')) onDetailKey(e, el);
  });
  $('#pop-search').addEventListener('input', function () { pick.q = this.value.trim(); renderPickList(); });

  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-act]');
    if (!e.target.closest('#pop') && (!b || b.getAttribute('data-act') !== 'pick')) closePicker();
    if (!b) return;
    var act = b.getAttribute('data-act'), list = b.getAttribute('data-list'), i = +b.getAttribute('data-i');
    var arr = list ? getPath(list) : null;
    switch (act) {
      case 'tab': ui.tab = b.getAttribute('data-v'); renderAll(); return;
      case 'rail':
        if (narrow.matches) ui.railNarrow = !ui.railNarrow; else ui.rail = !ui.rail;
        applyRail();
        return;
      case 'guide': var gid = b.getAttribute('data-id'); ui.guides[gid] = !ui.guides[gid]; renderForm(); return;
      case 'pick':
        if (pick.button === b) closePicker(); else openPicker(b);
        return;
      case 'pick-opt':
        setPath(pick.path, b.getAttribute('data-v'));
        closePicker();
        changed();
        return;
      case 'add':
        arr.push(blank(list, arr[arr.length - 1]));
        ui.enter = arr[arr.length - 1].uid || null;
        changed();
        var f = FIRST_FIELD[list] && form.querySelector('[data-path="' + list + '.' + (arr.length - 1) + '.' + FIRST_FIELD[list] + '"]');
        if (f) f.focus();
        return;
      case 'del':
        arr.splice(i, 1);
        if (!arr.length) arr.push(blank(list));
        changed();
        return;
      case 'up':
      case 'down':
        var j = act === 'up' ? i - 1 : i + 1, tmp = arr[i];
        arr[i] = arr[j]; arr[j] = tmp;
        changed();
        return;
      case 'dup':
        var copy = JSON.parse(JSON.stringify(arr[i]));
        copy.uid = nid();
        arr.splice(i + 1, 0, copy);
        ui.enter = copy.uid;
        changed();
        return;
      case 'fold-item': var fu = b.getAttribute('data-uid'); ui.collapsed[fu] = !ui.collapsed[fu]; renderForm(); return;
      case 'order': state[b.getAttribute('data-tab')].ordered = b.getAttribute('data-v') === '1'; changed(); return;
      case 'method': state.test.items[i].method = b.getAttribute('data-v'); changed(); return;
      case 'eye': ui.showToken = !ui.showToken; renderForm(); renderPreview(); return;
      case 'ref':
        var token = '{' + b.getAttribute('data-n') + '번 응답 ' + FIELD + '}';
        var focused = document.activeElement, owner = b.closest('.item');
        if (focused && owner && owner.contains(focused) && focused.getAttribute && focused.getAttribute('data-path')) {
          insertText(focused, token);
          selectField(focused);
        } else {
          state.test.items[i].api += token;
          changed();
          var apiEl = form.querySelector('[data-path="test.items.' + i + '.api"]');
          if (apiEl) { apiEl.focus(); apiEl.setSelectionRange(apiEl.value.length, apiEl.value.length); selectField(apiEl); }
        }
        return;
      case 'file-add':
        var ta = b.closest('.item').querySelector('textarea.code-ta');
        var slot = document.activeElement === ta ? valueSlot(ta) : null;
        if (!slot) { toast('본문에서 파일을 넣을 필드 값 자리("필드명": 뒤)를 먼저 클릭하세요'); return; }
        fileTarget = { ta: ta, from: slot.from, to: slot.to, quote: slot.quote };
        pickFile();
        return;
      case 'file-change':
        fileTarget = { i: i, key: b.getAttribute('data-key') };
        pickFile();
        return;
      case 'format': formatTa(form.querySelector('textarea[data-path="' + b.getAttribute('data-path') + '"]')); return;
      case 'preview':
        ui.preview = !ui.preview;
        $('#work').classList.toggle('wide', !ui.preview);
        b.classList.toggle('on', ui.preview);
        return;
      case 'fold': ui.foldGuide = !ui.foldGuide; renderPreview(); return;
      case 'modal-keep':
        /* 바뀐 md 위에 화면 내용을 덮어씀 */
        var keep = ui.conflict;
        closeModal();
        sync[keep.tab].base = keep.version;
        setSaveText('저장 중…', true);
        save(keep.tab, true);
        return;
      case 'modal-load':
        var load = ui.conflict;
        closeModal();
        loadTab(load.tab, load.text, load.version);
        renderAll();
        setSynced();
        setSaveText('저장됨 · ' + clock());
        toast(FILES[load.tab] + ' 최신 내용으로 화면을 바꿨습니다');
        return;
      case 'modal-diff':
        var box = $('#conflict-box');
        box.classList.add('anim');
        clearTimeout(animTimer);
        animTimer = setTimeout(function () { box.classList.remove('anim'); }, 380);
        $('#diff').classList.toggle('show');
        box.classList.toggle('large', $('#diff').classList.contains('show'));
        return;
    }
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closePicker();
  });
  document.addEventListener('mousedown', function (e) {
    if (e.target.closest && e.target.closest('.chip, [data-act="file-add"]')) e.preventDefault();
  });
  document.addEventListener('focusin', function (e) {
    var item = e.target.closest ? e.target.closest('.item') : null;
    var uid = item ? item.getAttribute('data-uid') : null;
    if (uid !== ui.focusUid) { ui.focusUid = uid; ui.scrollHot = !!uid; renderPreview(); }
  });
  window.addEventListener('scroll', function () {
    $('#head').classList.toggle('scrolled', window.scrollY > 4);
    closePicker();
  }, { passive: true });

  /* 미리보기 폭 조절 (메모리에만, 저장 안 함) */
  var drag = null;
  $('#resizer').addEventListener('mousedown', function (e) {
    drag = { x: e.clientX, w: document.querySelector('.preview').getBoundingClientRect().width || 560 };
    $('#resizer').classList.add('drag');
    document.body.style.userSelect = 'none';
    e.preventDefault();
  });
  window.addEventListener('mousemove', function (e) {
    if (!drag) return;
    /* 440~800px, 입력 칸은 최소 560px 유지 */
    var room = $('#work').getBoundingClientRect().width - 574;
    var w = Math.max(440, Math.min(800, room, drag.w + (drag.x - e.clientX)));
    $('#work').style.setProperty('--pv-w', w + 'px');
  });
  window.addEventListener('mouseup', function () {
    if (!drag) return;
    drag = null;
    $('#resizer').classList.remove('drag');
    document.body.style.userSelect = '';
  });

  /* 사이드바: 넓은 창은 버튼으로 고른 상태, 1400px 미만이면 자동으로 접힘 (메모리에만, 저장 안 함) */
  var narrow = window.matchMedia('(max-width: 1399px)');
  function applyRail() { $('#shell').classList.toggle('rail', narrow.matches ? ui.railNarrow : ui.rail); }
  narrow.addEventListener('change', function () { ui.railNarrow = true; applyRail(); });
  applyRail();

  /* 탭을 닫거나 새로고침할 때: 저장 안 된 입력은 바로 보냄 (충돌 중이면 안 보냄 → 다시 열면 md 기준) */
  window.addEventListener('pagehide', function () {
    if (ui.conflict) return;
    ['task', 'test'].forEach(function (tab) {
      var sy = sync[tab];
      if (!sy.ok || !dirty(tab) || sy.inflight) return;
      navigator.sendBeacon('/api/save?t=' + encodeURIComponent(TOKEN),
        new Blob([JSON.stringify({ tab: tab, text: currentMd(tab), base: sy.base, force: false })], { type: 'text/plain' }));
    });
  });

  /* ---------- 시작: md 두 개와 폴더 이름을 받고, 이후 변경은 서버가 바로 알려줌 ---------- */
  function setConn(on) {
    $('#st-dot').classList.toggle('off', !on);
    $('#st-conn').textContent = on ? 'md와 실시간 미러링 중' : '서버 연결 끊김 · 다시 연결 중';
  }
  function applyState(d, first) {
    WORKSPACE = d.folders || WORKSPACE;
    ['task', 'test'].forEach(function (tab) {
      var f = d[tab];
      if (!f || !f.exists) {
        sync[tab].ok = false;
        sync[tab].error = '.claude/' + tab + '/' + FILES[tab] + ' 파일이 없습니다';
        sync[tab].raw = '';
        return;
      }
      if (first) loadTab(tab, f.text, f.version);
      else onRemote(tab, f.text, f.version);
    });
  }
  function connect() {
    var events = new EventSource('/api/events?t=' + encodeURIComponent(TOKEN));
    /* (다시) 연결되면 그 사이 바뀐 게 있는지 한 번 맞춰 봄 */
    events.addEventListener('open', function () {
      setConn(true);
      api('/api/state').then(function (d) { applyState(d, false); refreshCounts(); });
    });
    events.addEventListener('error', function () { setConn(false); });
    events.addEventListener('file', function (e) {
      var d = JSON.parse(e.data);
      onRemote(d.tab, d.text, d.version);
    });
  }
  api('/api/state').then(function (d) {
    applyState(d, true);
    renderAll();
    setSynced();
    setSaveText('저장됨');
    connect();
  }, function () {
    setConn(false);
    toast('Editor 서버에 연결할 수 없습니다');
  });
}());
</script>
</body>
</html>
"""

if __name__ == '__main__':
    main()
