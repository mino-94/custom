# TEST

## 대상 프로젝트 및 호스트
<!--
  테스트 대상 프로젝트와 호스트 명시. 여러 프로젝트인 경우 모두 명시.
  개발/운영 환경인 경우 Authorization Bearer Token 함께 명시.

  예) cyclepay-api: http://localhost:9080
      cyclepay-authorization: http://localhost:9081

  개발/운영 예시)
  Authorization: Bearer {token}
  cyclepay-api: https://dev-api.cyclepay.kr
-->


## 테스트 내용
<!--
  표기 방식: [프로젝트명] Method + API + { 데이터 }

  데이터는 JSON 형태로 통일.

  Content-Type은 **짱구**가 메소드와 데이터를 보고 알아서 판단한다.
  - GET, DELETE → querystring (Content-Type 불필요)
  - POST, PUT, PATCH → application/json
  - multipart 필드 있으면 → multipart/form-data, 해당 필드에 (multipart) 표기

  여러 테스트인 경우 번호를 붙여 순서와 의존관계를 기술한다.
  - 순번 있음 → 연관 테스트, 완료 후 다음 진행 (1요청 1작업)
  - 순번 없음 → 독립 테스트 (1요청 N작업)

  예시)
  [cyclepay-api] POST /v1/files
  {
    "file": "/path/to/file.jpg (multipart)",
    "name": "테스트"
  }

  1. [cyclepay-api] POST /v1/payments { "amount": 1000, "method": "PM01" }
  2. [cyclepay-api] GET /v1/payments/{1번 응답 id}
  3. [cyclepay-auth] PATCH /v1/tokens { "id": "{1번 응답 id}", "status": "PM02" }
-->
